[]

NOMBRE: JERÓNIMO SILVA MULERO

[]



USUARIO-----------------------------------------------------------------------------------

1. Crea un usuario llamado “empleados” con clave “empleados” y concédele los permisos 
“connect” y “resource”. Conéctate desde ese usuario.

CREATE USER empleados IDENTIFIED BY empleados;

GRANT CONNECT, RESOURCE TO empleados;



TABLA-------------------------------------------------------------------------------------

2. Crea una tabla llamada “empleados_planta_valencia” con los siguientes campos:

Nombre     Tipo           Restricción
num_id     number(5)     primary key
nif        varchar2(9)   unique
nombre     varchar2(10)
apellido1  varchar2(10)
apellido2  varchar2(10)
fecha_nac  date
salario    number(5)
direccion  varchar2(30)
telefono   number(9)
email      varchar2(20)  unique
iban       number(20)
millonario number(1)



CREATE TABLE empleados_planta_valencia(
	num_id     NUMBER(5),     
	nif        VARCHAR2(9) UNIQUE,   
	nombre     VARCHAR2(10),
	apellido1  VARCHAR2(10),
	apellido2  VARCHAR2(10),
	fecha_nac  DATE,
	salario    NUMBER(5),
	direccion  VARCHAR2(30),
	telefono   NUMBER(9),
	email      VARCHAR2(20) UNIQUE, 
	iban       NUMBER(20),
	millonario NUMBER(1) 
);

ALTER TABLE empleados_planta_valencia ADD CONSTRAINT PK_empl PRIMARY KEY(num_id);

DROP TABLE empleados_planta_valencia CASCADE CONSTRAINTS;



SINÓNIMOS----------------------------------------------------------------------------------

3. Crea el sinónimo “t_empval” para la tabla anterior.

CREATE SYNONYM t_empval FOR empleados_planta_valencia;



4. Realiza un insert y un select de todos los datos utilizando el sinónimo.



INSERT INTO t_empval (num_id, nif, nombre) VALUES ('00001', '78523659E', 'Diego');

SELECT  num_id FROM t_empval;

SELECT  * FROM t_empval;








ÍNDICES-------------------------------------------------------------------------------------

5. Crea el índice “nombrecompleto” que contenga las columnas nombre, apellido1 y apellido2.
¿En qué casos se utilizaría?

CREATE INDEX nombrecompleto ON empleados_planta_valencia (apellido1, apellido2, nombre);

Se utilizaría para referenciar o buscar los tres campos a la vez (el nombre, el primer aoellido y el segundo apellido) tan sólo 
con usar la palabra creada como índice, en este caso "nombrecompleto"







6. Crea el índice del campo email. Si no se puede, indica el motivo.

CREATE INDEX email ON empleados_planta_valencia (email);

No se puede crear porque esta linea de columna (la del campo email) ya esta creada.






7. ¿Sería apropiado crear un índice de la columna “millonario”?

CREATE INDEX millonario ON empleados_planta_valencia (millonario, nombre);

Sí, así se podría unir el campo nombre con la columna millonario, para indicar si ese nombre corresponde  a alguien millonario o no.





SECUENCIAS------------------------------------------------------------------------------------

8. Crea una secuencia llamada “numero_id_planta_valencia”con las siguientes características:

• Que incremente de 1 en 1
• Que empiece por 10000
• Que termine en 99999
• Que no sea cíclico

CREATE SEQUENCE numero_id_planta_valencia
INCREMENT BY 1 
START WITH 10000
MAXVALUE 99999
NOCYCLE;  






9. Crea una secuencia que se llame “num_iban_planta_valencia” con las siguientes características:

• Que incremente de 5 en 5
• Que empiece por “20000000000000000000”
• Que termine en “99999999999999999999”
• Que no sea cíclica

CREATE SEQUENCE num_iban_planta_valencia
INCREMENT BY 5 
START WITH 20000000000000000000
MAXVALUE 99999999999999999999
NOCYCLE;






10. Modificar la secuencia anterior para que el incremento sea de 10 en 10.

ALTER SEQUENCE num_iban_planta_valencia
INCREMENT BY 10;




11. Obten el valor que se asignará cuando se ejecute la sentencia NEXTVAL en esta secuencia.

SELECT num_iban_planta_valencia.NEXTVAL FROM DUAL;





VISTAS---------------------------------------------------------------------------------------

12. Crea una vista sobre la tabla que hemos trabajado, que se llame “v_empval” y sea el resultado 
de seleccionar los siguientes campos de la tabla:

• nif
• nombre
• apellido1
• apellido2
• telefono


CREATE VIEW v_empval
AS SELECT nif, nombre, apellido1, apellido2, telefono FROM empleados_planta_valencia;





13. Realiza una selección sobre esa vista.

SELECT * FROM v_empval;



14. ¿Qué utilidades encontrarías a la creación de tablas en este caso?

Lograr una vista clara y organizada, a primer golpe de vista de la información de los empleados de la planta en valencia, 
dividiendo los campos en filas y columnas.