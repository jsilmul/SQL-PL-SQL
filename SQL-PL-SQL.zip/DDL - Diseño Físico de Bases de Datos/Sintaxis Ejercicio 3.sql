[]

NOMBRE: JERÓNIMO SILVA MULERO

[]


Usuario (SQL Developer).............................................................................................................................................

1. Crea un usuario llamado “empresaXX” con clave “empresaXX” y concédele los permisos 
“connect” y “resource”. Conéctate desde ese usuario.
 


CREATE USER empresa11 IDENTIFIED BY empresa11;

GRANT CONNECT, RESOURCE TO empresa11;





Tabla (SQL Developer).............................................................................................................................................

2. Crea las tablas y restricciones necesarias para representar el siguiente esquema relacional:



---------------------tabla empleados------------------------------------------------------------

CREATE TABLE EMPLEADOS(
	DNI VARCHAR2(9),		
	NOMBRE VARCHAR2(15) NOT NULL, 
	APELLIDO VARCHAR2(15),
    DIRECCION VARCHAR2(20),
	CIUDAD VARCHAR2(15),
	MUNICIPIO VARCHAR2(15),
	COD_POSTAL NUMBER(5),
	SEXO VARCHAR2(6)
);

ALTER TABLE EMPLEADOS ADD CONSTRAINT PK_EMPL PRIMARY KEY(DNI);

DROP TABLE EMPLEADOS CASCADE CONSTRAINTS;





---------------------tabla historial_salarial------------------------------------------------------

CREATE TABLE HISTORIAL_SALARIAL(
	CODIGO NUMBER(5),		
	SALARIO NUMBER(10), 
	FECHA_COMIENZO DATE,
    FECHA_FIN DATE
);


ALTER TABLE HISTORIAL_SALARIAL ADD CONSTRAINT PK_HIST PRIMARY KEY(CODIGO);

DROP TABLE HISTORIAL_SALARIAL CASCADE CONSTRAINTS;






---------------------tabla trabajos-----------------------------------------------------------------

CREATE TABLE TRABAJOS(
	TRABAJO_COD NUMBER(5),
	NOMBRE_TRAB VARCHAR2(15),
	SALARIO_MIN NUMBER(10),	
	SALARIO_MAX NUMBER(10)	
);

ALTER TABLE TRABAJOS ADD CONSTRAINT PK_TRAB PRIMARY KEY(TRABAJO_COD);

DROP TABLE TRABAJOS CASCADE CONSTRAINTS;






---------------------tabla estudios-------------------------------------------------------------------

CREATE TABLE ESTUDIOS(
	CODIGO NUMBER(5),		
	TITULO VARCHAR2(15),
     	CIUDAD VARCHAR2(15)
);

ALTER TABLE ESTUDIOS ADD CONSTRAINT PK_ESTU PRIMARY KEY(CODIGO);


DROP TABLE ESTUDIOS CASCADE CONSTRAINTS;






---------------------tabla departamentos------------------------------------------------------------------

CREATE TABLE DEPARTAMENTOS(
	DTPO_COD NUMBER(5),		
	NOMBRE_DTPO VARCHAR2(15),
     	PRESUPUESTO NUMBER(10),
	PRES_ACTUAL NUMBER(10)
);

ALTER TABLE DEPARTAMENTOS ADD CONSTRAINT PK_DEPA PRIMARY KEY(DTPO_COD);


DROP TABLE DEPARTAMENTOS CASCADE CONSTRAINTS;





---------------------tabla historial_laboral---------------------------------------------------------------

CREATE TABLE HISTORIAL_LABORAL(
	DNI VARCHAR2(9),		
	TRABAJO_COD NUMBER(5),
    FECHA_INICIO DATE,
    FECHA_FIN DATE
);

ALTER TABLE HISTORIAL_LABORAL ADD CONSTRAINT PK_HISL PRIMARY KEY(DNI, TRABAJO_COD);

ALTER TABLE HISTORIAL_LABORAL ADD CONSTRAINT FK_DNI FOREIGN KEY (DNI) REFERENCES EMPLEADOS;
ALTER TABLE HISTORIAL_LABORAL ADD CONSTRAINT FK_TRABAJO_COD FOREIGN KEY (TRABAJO_COD) REFERENCES TRABAJOS;


DROP TABLE HISTORIAL_LABORAL CASCADE CONSTRAINTS;






Sinónimos (SQL Plus).............................................................................................................................................

3. Crea un sinónimo justificando tu elección

CREATE SYNONYM H_L FOR HISTORIAL_LABORAL;

CREATE SYNONYM H_S FOR HISTORIAL_SALARIAL;

He creado dos sinonimos, así, logramos acortar y resumir el nombre de esta tabla (HISTORIAL_LABORAL) con el sinonimo H_L, y la diferenciamos 
de HISTORIAL_SALARIAL, dado que ambas empiezan por HISTORIAL. A la tabla HISTORIAL_SALARIAL tambien le creamos un sinonimo, H_S.




Índices (SQL Plus).............................................................................................................................................

4. Crea un índice justificando tu elección.


CREATE INDEX FECHA_TRABAJO ON HISTORIAL_LABORAL (FECHA_INICIO, FECHA_FIN);

Creo este índice para ubicar con sólo comando dos campos a la vez (la fecha de inicio y de fin del historial salarial) del empleado o empleada en sí, tan sólo 
con usar la palabra creada como índice, en este caso "FECHA_TRABAJO". Con esto podemos ver cuando ha empezado y terminado su historial laboral.




Secuencias (SQL Plus).............................................................................................................................................

5. Elige una tabla y atributo, y justificando tu elección crea una secuencia que creas que podrías aplicar. Explica sus parámetros.

CREATE SEQUENCE CODIGO_SALARIOS
INCREMENT BY 1 
START WITH 20
MAXVALUE 99999
NOCYCLE;


Con esta secuencia, llamada CODIGO_SALARIOS, vemos el codigo del trabajo, el minimo salario de un trabajo a partir de un valor minimo de 20
(entiendase 20 euros) y un valor maximo de 99999 como el salario maximo, incrementado de 1 en 1 (de un euro en un euro ) y que no se
repita cuando llega al final, es decir, que no sea cíclico.




Vistas (SQL Plus)................................................................................................................................................

6. Crea una vista que nos ofrezca alguna utilidad. Justifica tu elección.

CREATE VIEW INF_DEPART
AS SELECT DTPO_COD, NOMBRE_DTPO, PRESUPUESTO FROM DEPARTAMENTOS;


Esta vista trabaja sobre la tabla DEPARTAMENTOS, y se llama “INF_DEPART”, donde INF significa informacion, y DEPART lógicamente departamentos. 
Seleccionamos estos dos campos de la tabla, con la informacion más básica de los departamentos: el codigo de departamento, el nombre del departamento 
y su presupuesto.