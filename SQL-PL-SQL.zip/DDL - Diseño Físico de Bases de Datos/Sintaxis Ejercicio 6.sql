[]

NOMBRE: JERÓNIMO SILVA MULERO

[]

CONNECT SYSTEM
MANAGER


CREATE USER banco00 IDENTIFIED BY banco00 QUOTA 5M ON USERS;

GRANT CONNECT, RESOURCE TO banco00;

GRANT CREATE SYNONYM TO banco00;

GRANT CREATE VIEW TO banco00;

---COMMIT WORK; //OPCION DE GUARDADO


-------------------------------------------------------------------tabla sucursal
CREATE TABLE sucursal(
	CodSucursal NUMBER(5),
	Nombre VARCHAR2(15),
	Direccion VARCHAR2(40),
	Localidad VARCHAR2(15)
);

ALTER TABLE sucursal ADD CONSTRAINT PK_Sucursal PRIMARY KEY(CodSucursal);

--PARA COMPROBAR QUE SE HA INTRODUCIDO CORRECTAMENTE, DESCRIBE sucursal; 

--O BIEN, SELECT * FROM AL_CONSTRAINTS WHERE OWNER = 'banco00' AND Sucursal;

--O BIEN, SELECT * FROM AL_CONSTRAINTS WHERE CONSTRAINT NAME = 'PK_Sucursal';


DROP TABLE sucursal CASCADE CONSTRAINTS;







-------------------------------------------------------------------tabla cliente
CREATE TABLE cliente(
	DNI VARCHAR2(9),
	Nombre VARCHAR2(15),
	Direccion VARCHAR2(40),
	Localidad VARCHAR2(15),
	FechaNac DATE,
	Sexo VARCHAR2(1)
);

ALTER TABLE cliente ADD CONSTRAINT PK_cliente PRIMARY KEY(DNI);


DROP TABLE cliente CASCADE CONSTRAINTS;






-------------------------------------------------------------------tabla cuenta
CREATE TABLE cuenta(
	CodSucursal NUMBER(5),
	CodCuenta NUMBER(20)
);

ALTER TABLE cuenta ADD CONSTRAINT PK_cuenta PRIMARY KEY(CodSucursal, CodCuenta);
//ALTER TABLE cuenta ADD CONSTRAINT PK_cuenta PRIMARY KEY(CodCuenta);

ALTER TABLE cuenta ADD CONSTRAINT FK_cuenta1 FOREIGN KEY(CodSucursal) REFERENCES sucursal;


DROP TABLE cuenta CASCADE CONSTRAINTS;






-------------------------------------------------------------------tabla transaccion
CREATE TABLE transaccion(
	CodSucursal NUMBER(5),
	CodCuenta NUMBER(20),
	NumTransaccion NUMBER(5),
	Fecha DATE,
	Cantidad NUMBER(7,2),
	Tipo VARCHAR2(1) 
);

ALTER TABLE transaccion ADD CONSTRAINT PK_transaccion PRIMARY KEY(CodSucursal, CodCuenta, NumTransaccion);

ALTER TABLE transaccion ADD CONSTRAINT FK_transaccion FOREIGN KEY(CodSucursal, CodCuenta) REFERENCES cuenta;


DROP TABLE transaccion CASCADE CONSTRAINTS;







-------------------------------------------------------------------tabla cli_cuenta
CREATE TABLE cli_cuenta(
	CodSucursal NUMBER(5),
	CodCuenta NUMBER(20),
	DNI VARCHAR2(9)
);

ALTER TABLE cli_cuenta ADD CONSTRAINT PK_cli_cuenta PRIMARY KEY(CodSucursal, CodCuenta, DNI);

ALTER TABLE cli_cuenta ADD CONSTRAINT FK_cli_cuenta1 FOREIGN KEY(CodSucursal, CodCuenta) REFERENCES cuenta;

ALTER TABLE cli_cuenta ADD CONSTRAINT FK_cli_cuenta2 FOREIGN KEY(DNI) REFERENCES cliente;




DROP TABLE cli_cuenta CASCADE CONSTRAINTS;







-------------------------------------------------Modificar el ancho de columna del código de sucucursal. Presta atención a la coherencia entre tablas

ALTER TABLE transaccion MODIFY (CodSucursal NUMBER(10));

ALTER TABLE cuenta MODIFY (CodSucursal NUMBER(10));

ALTER TABLE sucursal MODIFY (CodSucursal NUMBER(10));

ALTER TABLE cli_cuenta MODIFY (CodSucursal NUMBER(10));






----Añade la tabla teléfonos y enlázalo a clientes, de tal forma que cada cliente pueda tener más de un teléfono asignado. Considerar teléfonos una 
----entidad débil con clave compuesta de DNI y un contador de teléfonos de cada usuario.

-------------------------------------------------------------------tabla telefonos
CREATE TABLE telefonos(
	NumTelefono NUMBER(9) 	PRIMARY KEY,
	DNI VARCHAR2(9)			REFERENCES cliente
);

--RESTRICCION DE COLUMNA:          DNI VARCHAR2(9)			REFERENCES cliente
--COMO RESTRICCION DE TABLA SERÍA: ALTER TABLE telefonos ADD CONSTRAINT FK_telefonos FOREIGN KEY (DNI) REFERENCES cliente;

ALTER TABLE telefonos ADD ind_tel NUMBER(1);

DROP TABLE telefonos CASCADE CONSTRAINTS;




------------------Añade a la tabla cliente el campo “email”:

ALTER TABLE cliente ADD (Email VARCHAR2 (20));-----------------------------------AÑADIMOS EL CAMPO EMAIL

ALTER TABLE cliente ADD CONSTRAINT CK_Mail CHECK  (Email LIKE '%@%.COM');-------PARA COMPROBAR QUE EL CAMPO EMAIL TENGA EL FORMATO CORRECTO






----------------------Crea los siguientes chequeos en las tablas (restricciones).


--Edad mayor o igual a 18

ALTER TABLE cliente ADD (Edad NUMBER (2));---------------------------------------AÑADIMOS EL CAMPO EDAD

ALTER TABlE cliente ADD CONSTRAINT CK_Edad CHECK (Edad >= 18);-------------------PARA COMPROBAR QUE EL CAMPO EDAD TENGA IGUAL O MÁS DE 18 AÑOS




--Fecha de transacción igual o posterior a hoy
ALTER SESSION SET NLS_DATE_FORMAT = 'DD/MM/YYYY';

ALTER TABlE transaccion ADD CONSTRAINT CK_Fec CHECK (Fecha >= '01/02/2022');--------------------NO HACER----Fecha de transacción igual o posterior a hoy



--Fecha de nacimiento anterior a hoy.
ALTER TABlE cliente ADD CONSTRAINT CK_FeNa CHECK (FechaNac <= '01/02/2022'); -------------------NO HACER--------Fecha de nacimiento anterior a hoy




--Tipo de transacción: T – Transferencia, D – Domiciliación
ALTER TABLE transaccion  ADD CONSTRAINT CK_Tyd CHECK (Tipo IN ('T', 'D'));



--Localidad (para sucursal y cliente) debe empezar en una letra mayúscula
ALTER TABLE sucursal ADD CONSTRAINT CK_Loc CHECK (Localidad = INITCAP (Localidad));




--Sexo del cliente debe ser: H – Hombre, M – Mujer 
ALTER TABLE cliente ADD CONSTRAINT CK_Sexo CHECK (Sexo IN ('H', 'M'));





-------------Modifica la restricción “Tipo de transacción” para añadir “I – Ingreso”
ALTER TABLE transaccion ADD CONSTRAINT CK_Ing CHECK (Tipo IN ('I'));





-----------------Crea 3 índices que consideres de utilidad.
CREATE INDEX info_cliente ON cliente (DNI, Nombre, Direccion);

CREATE INDEX info_transaccion ON transaccion (NumTransaccion, Fecha, Cantidad); 
	 
CREATE INDEX info_suscursal ON sucursal (Nombre, Direccion);




---------------------Crea secuencias para aquellos campos que consideres de utilidad.
CREATE SEQUENCE numero_transaccion
INCREMENT BY 1 
START WITH 10000
MAXVALUE 99999
NOCYCLE;  




---------------------Crea sinónimos para una tabla y una secuencia.
CREATE SYNONYM t_sucur FOR sucursal;

CREATE SYNONYM s_numtrans FOR numero_transaccion;



---------------------Crea una vista que simplifique la tabla de cliente.
CREATE VIEW view_clienteval AS SELECT DNI, Nombre, Direccion, Localidad, FechaNac, Sexo  FROM cliente;




---------------------Realiza una inserción para cada tabla.

INSERT INTO cliente (DNI, Nombre, Direccion, Localidad, FechaNac, Sexo, Email, Edad) VALUES ('78523652O', 'Federico','Calle Mayor', 'Madrid', '20/05/1990', 'H', 'algo@algo.COM', '31');

INSERT INTO sucursal (CodSucursal, Nombre, Direccion, Localidad) VALUES ('00001', 'Zona Norte', 'Calle Ancha', 'Malaga');

INSERT INTO cuenta (CodSucursal, CodCuenta) VALUES ('00001', '98787645678765456543');

INSERT INTO transaccion (CodSucursal, CodCuenta, NumTransaccion, Fecha, Cantidad, Tipo) VALUES ('00001', '98787645678765456543', '00323', '04/09/2021', '80000', 'I'); 
 
INSERT INTO cli_cuenta (CodSucursal, CodCuenta, DNI) VALUES ('00001', '98787645678765456543', '78523652O'); 

INSERT INTO telefonos (NumTelefono, DNI, ind_tel) VALUES ('965274859', '78523652O', '6'); 




---------------------Realiza algún SELECT de una tabla y de la vista creada anteriormente. 
SELECT * FROM cliente;
SELECT * FROM sucursal;
SELECT * FROM cuenta;
SELECT * FROM transaccion;
SELECT * FROM cli_cuenta;
SELECT * FROM telefonos;



---------------------Vacía todas las tablas.

DELETE FROM  sucursal;
DELETE FROM  cliente;
DELETE FROM  cuenta;
DELETE FROM  transaccion;
DELETE FROM  cli_cuenta;
DELETE FROM  telefonos;





---------------------Elimina la tabla de teléfonos
DROP TABLE telefonos CASCADE CONSTRAINTS;





COMMIT WORK; //OPCION DE GUARDADO, LO ESCRIBIMOS AL FINAL