*******************

[]

NOMBRE: JERÓNIMO  SILVA MUULERO

[]


*******************



Usuario (SQL Developer)

1. Crea un usuario llamado “pedidosXX” con clave “pedidosXX” y concédele los permisos 
“connect”, “resource”, “create synonym”, “create view”, “create any index”, “create any 
sequence”. Conéctate desde ese usuario.

CONNECT SYSTEM
		MANAGER
		
CREATE USER PEDIDOS11 IDENTIFIED BY PEDIDOS11; QUOTA 5M ON USERS;

GRANT CONNECT, RESOURCE TO PEDIDOS11;

GRANT CREATE VIEW TO PEDIDOS11;

GRANT CREATE SYNONYM TO PEDIDOS11;

CONNECT PEDIDOS11
		PEDIDOS11
		
		
		
		

Tabla (SQL Developer)

2. Crea las tablas inicialmente SIN RESTRICCIONES y posteriormente añade las que sean 
necesarias para representar el siguiente esquema relacional:

-----------------------------------------------------------------------------------------------------------Tabla Cliente11
CREATE TABLE CLIENTE11(
	NUMCLIENTE NUMBER(5),
	SALDO NUMBER(8),
	LIMCREDITO NUMBER(8),
	DESCUENTO VARCHAR2 (3)
); 
ALTER TABLE CLIENTE11 ADD CONSTRAINT PK_CLIENTE11 PRIMARY KEY(NUMCLIENTE);








-----------------------------------------------------------------------------------------------------------Tabla Posee11
CREATE TABLE POSEE11(
	NUMCLIENTE NUMBER(5),
	CODDIRECCION NUMBER(5)
);
ALTER TABLE POSEE11 ADD CONSTRAINT PK_POSEE11 PRIMARY KEY(NUMCLIENTE, CODDIRECCION);

ALTER TABLE POSEE11 ADD CONSTRAINT FK_POSEE112 FOREIGN KEY(NUMCLIENTE) REFERENCES CLIENTE11;
ALTER TABLE POSEE11 ADD CONSTRAINT FK_POSEE113 FOREIGN KEY(CODDIRECCION) REFERENCES DIRECCION11;




-----------------------------------------------------------------------------------------------------------Tabla Direccion11
CREATE TABLE DIRECCION11(
	CODDIRECCION NUMBER(5),
	VIA VARCHAR2 (10),
	NOMBREVIA VARCHAR2(30),
	NUMERO NUMBER(3),
	PISO NUMBER(2),
	PORTAL NUMBER(3),
	CODPOSTAL NUMBER(5)
);
ALTER TABLE DIRECCION11 ADD CONSTRAINT PK_DIRECCION11 PRIMARY KEY(CODDIRECCION);







-----------------------------------------------------------------------------------------------------------Tabla Pedido11
CREATE TABLE PEDIDO11(
	NUMPEDIDO NUMBER(5),	 
	FECHA DATE,
	NUMCLIENTE NUMBER(5),
	CODDIRECCION NUMBER(5)
);
ALTER TABLE PEDIDO11 ADD CONSTRAINT PK_PEDIDO11 PRIMARY KEY(NUMPEDIDO);

ALTER TABLE PEDIDO11 ADD CONSTRAINT FK_PEDIDO112 FOREIGN KEY(NUMCLIENTE) REFERENCES CLIENTE11;
ALTER TABLE PEDIDO11 ADD CONSTRAINT FK_PEDIDO113 FOREIGN KEY(CODDIRECCION) REFERENCES DIRECCION11;





-----------------------------------------------------------------------------------------------------------Tabla Incluye11
CREATE TABLE INCLUYE11(
	NUMPEDIDO NUMBER(5),
	NUMARTICULO NUMBER(5),
	CANTIDAD NUMBER(5)
);
ALTER TABLE INCLUYE11 ADD CONSTRAINT PK_INCLUYE11 PRIMARY KEY(NUMPEDIDO, NUMARTICULO);

ALTER TABLE INCLUYE11 ADD CONSTRAINT FK_INCLUYE112 FOREIGN KEY(NUMPEDIDO) REFERENCES PEDIDO11;
ALTER TABLE INCLUYE11 ADD CONSTRAINT FK_INCLUYE113 FOREIGN KEY(NUMARTICULO) REFERENCES ARTICULO11;






-----------------------------------------------------------------------------------------------------------Tabla Articulo11
CREATE TABLE ARTICULO11(
	NUMARTICULO NUMBER(5),
	DESCRIPCION VARCHAR2(15)
);
ALTER TABLE ARTICULO11 ADD CONSTRAINT PK_ARTICULO11 PRIMARY KEY(NUMARTICULO);







-----------------------------------------------------------------------------------------------------------Tabla Distribuye11
CREATE TABLE DISTRIBUYE11(
	NUMARTICULO NUMBER(5),
	NUMFABRICA NUMBER(5),
	CANTSUMINISTRO NUMBER(8),
	EXISTENCIAS NUMBER(8)
);
ALTER TABLE DISTRIBUYE11 ADD CONSTRAINT PK_DISTRIBUYE11 PRIMARY KEY(NUMARTICULO, NUMFABRICA);

ALTER TABLE DISTRIBUYE11 ADD CONSTRAINT FK_DISTRIBUYE112 FOREIGN KEY(NUMARTICULO) REFERENCES ARTICULO11;
ALTER TABLE DISTRIBUYE11 ADD CONSTRAINT FK_DISTRIBUYE113 FOREIGN KEY(NUMFABRICA) REFERENCES FABRICA11;





-----------------------------------------------------------------------------------------------------------Tabla Fabrica11
CREATE TABLE FABRICA11(
	NUMFABRICA NUMBER(5),
	TELEFONO NUMBER(9)
);
ALTER TABLE FABRICA11 ADD CONSTRAINT PK_FABRICA11 PRIMARY KEY(NUMFABRICA);







-------------------------------------------------------------------------------------------------------------------------
Sinónimos (SQL Plus)
3. Crea un sinónimo justificando tu elección

CREATE SYNONYM DIR11 FOR DIRECCION11;

DIR11 acorta el nombre de la tabla original, DIRECCION11, haciendo más fácil y cómoda su referencia.


------------------------------------------------------------------------------------------------------------------------
Índices (SQL Plus)
4. Crea un índice justificando tu elección.

CREATE INDEX ECONO_CLIE11 ON CLIENTE11 (SALDO, LIMCREDITO, DESCUENTO);

Usando los campos SALDO, LIMCREDITO y DESCUENTO, obtenemos una visión económiva de los clientes de la tabla CLIENTE11



------------------------------------------------------------------------------------------------------------------------
Secuencias (SQL Plus)
5. Elige una tabla y atributo, y justificando tu elección crea una secuencia que creas que 
podrías aplicar. Explica sus parámetros.

CREATE SEQUENCE NOARTICULO11
INCREMENT BY 1
START WITH 00001
MINVALUE 00001
MAXVALUE 99999
NOCYCLE;  

Secuencia de los numeros de los articulos de la tabla ARTICULOS11. Se incrementa de 1 en 1. Empieza en 00001, como valor 
inicial, que es el valor mínimo de la rueda de la secuencia. El máximo valor es de 99999, es decir, no puede haber una 
valor susperior a esa cifra. Y NOCYCLE significa que no es cíclico, que la rueda de la secuencia no se repite.



---------------------------------------------------------------------------------------------------------------------------
 Vistas (SQL Plus)
6. Crea una vista que nos ofrezca alguna utilidad. Justifica tu elección

CREATE VIEW INFO_BASICA_DIRE11 AS SELECT VIA, NOMBREVIA, CODPOSTAL FROM DIRECCION11;

Con este índice, vemos de un vistazo, el tipo de vía, el nombre de tal vía y los códigos postales de la tabla DIRECCION11;