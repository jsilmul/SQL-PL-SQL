*****
Ejercicios Empresa Distribuidora
*****


[]

NOMBRE: JERÓNIMO SILVA MULERO

[]

-----------------------------------------------------------------------------------
CONNECT SYSTEM
		MANAGER

CREATE USER DISTRIBUCION11 IDENTIFIED BY DISTRIBUCION11 QUOTA 5M ON USERS;

GRANT CONNECT, RESOURCE TO DISTRIBUCION11;

GRANT CREATE SYNONYM TO DISTRIBUCION11;

GRANT CREATE VIEW TO DISTRIBUCION11;



CREATE TABLE DEPARTAMENTOS11(
 COD_DEPARTAMENTO NUMBER(2),
 NOMBRE VARCHAR2(40) NOT NULL,
 LOCALIDAD VARCHAR2(40) NOT NULL
);


ALTER TABLE DEPARTAMENTOS11 ADD CONSTRAINT PK_DEPARTAMENTOS11 PRIMARY KEY(COD_DEPARTAMENTO);


INSERT INTO DEPARTAMENTOS11 (COD_DEPARTAMENTO, NOMBRE, LOCALIDAD) VALUES ('10', 'CONTABILIDAD', 'BARCELONA');
INSERT INTO DEPARTAMENTOS11 (COD_DEPARTAMENTO, NOMBRE, LOCALIDAD) VALUES ('20', 'INVESTIGACION', 'VALENCIA');
INSERT INTO DEPARTAMENTOS11 (COD_DEPARTAMENTO, NOMBRE, LOCALIDAD) VALUES ('30', 'VENTAS', 'MADRID');
INSERT INTO DEPARTAMENTOS11 (COD_DEPARTAMENTO, NOMBRE, LOCALIDAD) VALUES ('40', 'PRODUCCION', 'SEVILLA');
INSERT INTO DEPARTAMENTOS11 (COD_DEPARTAMENTO, NOMBRE, LOCALIDAD) VALUES ('50', 'INFORMATICA', 'MADRID');





-----------------------------------------------------------------------------------HASTA AQUÍ, SQL PLUS

















-----------------------------------------------------------------------------------DESDE AQUÍ, SQL DEVELOPER

1. Un listado que contenga el código de cliente y nombre de todos los clientes que no se 
encuentren en ‘BARCELONA’, ordenados por nombre, alfabéticamente.

SELECT COUNT (COD_CLIENTE)
FROM CLIENTES
WHERE LOCALIDAD != 'BARCELONA'
ORDER BY NOMBRE ASC;




2. Un listado que contenga el nombre de los departamentos que se encuentran en la siguiente 
lista (se deben utilizar listas) de ciudades: Madrid, Barcelona.

SELECT NOMBRE
FROM DEPARTAMENTOS11
WHERE LOCALIDAD = 'BARCELONA' OR LOCALIDAD = 'MADRID';




3. El salario más bajo, el más alto y la media de la tabla de empleados.

SELECT MIN(SALARIO),MAX (SALARIO), AVG (SALARIO)
FROM EMPLEADOS; 



4. Un listado de productos (descripción, stock, precio) ordenados por stock de forma  descendente y por precio de forma descendente y alfabéticamente de forma ascendente.

SELECT DESCRIPCION, STOCK_DISPONIBLE, PRECIO_ACTUAL
FROM PRODUCTOS 
ORDER BY STOCK_DISPONIBLE DESC, 
PRECIO_ACTUAL DESC,
DESCRIPCION ASC;




5. Un listado de apellidos y fechas de alta de vendedores que no cobren comisiones

SELECT APELLIDO, FECHA_ALTA
FROM EMPLEADOS 
WHERE OFICIO = 'VENDEDOR'
AND COMISION IS NULL;		  



6. Un listado que contenga código de producto, descripción y stock de mesas con un stock comprendido entre 10 y 20 unidades.

SELECT COD_PRODUCTO, DESCRIPCION, STOCK_DISPONIBLE
FROM PRODUCTOS 
WHERE STOCK_DISPONIBLE BETWEEN 10 AND 20; 



7. Un listado que contenga los nombres y localidades de los clientes que alguna vez han sido atendidos por un director.

SELECT NOMBRE, LOCALIDAD
FROM CLIENTES
WHERE COD_VENDEDOR IN (SELECT COD_EMPLEADO
                       FROM EMPLEADOS 
                       WHERE OFICIO = 'DIRECTOR');


8. Listado con el nombre y localidad de los clientes que tienen pedidos con menos de 3 unidades en el mes de noviembre de 1999.

ALTER SESSION SET NLS_DATE_FORMAT = 'DD/MM/YYYY';

SELECT NOMBRE, LOCALIDAD
FROM CLIENTES
WHERE COD_CLIENTE IN (SELECT COD_CLIENTE
                      FROM PEDIDOS
					  WHERE FECHA_PEDIDO BETWEEN '01/11/1999' AND '30/11/1999'
                      HAVING UNIDADES < 3)
					  ORDER BY NOMBRE, LOCALIDAD;
					  
					  

9. Listado con el nombre y localidad de cliente, nombre de departamento, y apellido del empleado que le atendió para todos aquellos clientes 
que fueron atendidos por un empleado perteneciente a algún departamento de Madrid. 

El resultado debe mostrarse ordenado por orden alfabético del apellido del empleado y en caso de empate, por el del nombre de
cliente, también alfabéticamente.

SELECT CLIENTES.NOMBRE, DEPARTAMENTOS11.LOCALIDAD, DEPARTAMENTOS11.NOMBRE, APELLIDO
FROM CLIENTES, DEPARTAMENTOS11, EMPLEADOS
WHERE COD_VENDEDOR IN (SELECT COD_EMPLEADO
                       FROM EMPLEADOS 
					   WHERE OFICIO = 'VENDEDOR')
                       AND DEPARTAMENTOS11.LOCALIDAD = 'MADRID' 
                       ORDER BY APELLIDO ASC;
					   
					   
					   
10. Un listado con el nombre y localidad del cliente, apellido y nombre de departamento del empleado que le atendió, descripción del producto 
que compró y fecha del pedido, de todos  aquellos clientes que compraron una “…SILLA DIRECTOR…” en el mes de noviembre de 1999 ordenando los
resultados ascendentemente por fecha de pedido.

Por último, el cliente nos informa de que va a necesitar algunos informes estadísticos para 
los que vamos a necesitar algunas sentencias más complejas. En concreto necesitamos:

SELECT CLIENTES.NOMBRE, CLIENTES.LOCALIDAD, EMPLEADOS.APELLIDO, DEPARTAMENTOS11.NOMBRE, PRODUCTOS.DESCRIPCION, PEDIDOS.FECHA_PEDIDO
FROM CLIENTES, EMPLEADOS, DEPARTAMENTOS11, PRODUCTOS, PEDIDOS
WHERE CLIENTES.COD_VENDEDOR = EMPLEADOS.COD_EMPLEADO
AND EMPLEADOS.COD_DEPARTAMENTO = DEPARTAMENTOS11.COD_DEPARTAMENTO
AND CLIENTES.COD_CLIENTE = PEDIDOS.COD_CLIENTE
AND PEDIDOS.COD_PRODUCTO = PRODUCTOS.COD_PRODUCTO 
AND PRODUCTOS. DESCRIPCION LIKE '%SILLA DIRECTOR%'
AND FECHA_PEDIDO BETWEEN '01/11/1999' AND '30/11/1999'
ORDER BY PEDIDOS.FECHA_PEDIDO ASC;






11. Un listado con el nombre de la localidad y la suma del crédito que tienen sus clientes, 
agrupado por localidad.

SELECT LOCALIDAD, SUM(LIMITE_CREDITO)
FROM CLIENTES
GROUP BY LOCALIDAD;


12. Un listado que muestre nombre del departamento, oficio y media salarial, agrupado por  departamento y oficio, 
que tengan asignado un salario superior a 200000 €, todo ello ordenado descendentemente por la media salarial.

SELECT NOMBRE, OFICIO, AVG(SALARIO)
FROM DEPARTAMENTOS11, EMPLEADOS
WHERE SALARIO > 200000
GROUP BY NOMBRE, OFICIO
ORDER BY AVG(SALARIO) DESC; 




13. Un listado que muestre los códigos de cliente y nombres de los clientes cuya suma total de los pedidos (también hay que mostrarla) 
que han realizado sea mayor que 8.000.000€, ordenado ascendentemente por número de código de cliente.

SELECT CLIENTES.COD_CLIENTE, CLIENTES.NOMBRE, SUM (PRODUCTOS.PRECIO_ACTUAL * PEDIDOS.UNIDADES)
FROM CLIENTES, PEDIDOS, PRODUCTOS
WHERE PEDIDOS.COD_CLIENTE = CLIENTES.COD_CLIENTE
AND PEDIDOS.COD_PRODUCTO = PRODUCTOS.COD_PRODUCTO
GROUP BY CLIENTES.COD_CLIENTE, CLIENTES.NOMBRE
HAVING SUM (PEDIDOS.UNIDADES * PRODUCTOS.PRECIO_ACTUAL) > 8000000 
ORDER BY CLIENTES.COD_CLIENTE ASC;





14. Un listado de los departamentos, su ciudad y su número de empleados, cuyo departamento tenga más de 2 empleados, ordenado por número de 
empleados ascendentemente.

SELECT DEPARTAMENTOS11.NOMBRE, DEPARTAMENTOS11.LOCALIDAD, COUNT (EMPLEADOS.COD_EMPLEADO)
FROM DEPARTAMENTOS11, EMPLEADOS
WHERE EMPLEADOS.COD_DEPARTAMENTO = DEPARTAMENTOS11.COD_DEPARTAMENTO
GROUP BY DEPARTAMENTOS11.LOCALIDAD, DEPARTAMENTOS11.NOMBRE
HAVING COUNT (EMPLEADOS.COD_EMPLEADO) > 2
ORDER BY COUNT (EMPLEADOS.COD_EMPLEADO) ASC;




15. Un listado de los nombres de departamento y el mínimo salario de los departamentos en los que todos sus empleados cobren más de 135.000€, 
ordenado por salario minimo descendentemente y por nombre de departamento ascendentemente

SELECT DEPARTAMENTOS11.NOMBRE, MIN(EMPLEADOS.SALARIO)
FROM DEPARTAMENTOS11, EMPLEADOS
WHERE EMPLEADOS.COD_DEPARTAMENTO = DEPARTAMENTOS11.COD_DEPARTAMENTO 
GROUP BY DEPARTAMENTOS11.NOMBRE
HAVING MIN (EMPLEADOS.SALARIO) > 135000
ORDER BY DEPARTAMENTOS11.NOMBRE ASC, MIN (EMPLEADOS.SALARIO) DESC;                         						   