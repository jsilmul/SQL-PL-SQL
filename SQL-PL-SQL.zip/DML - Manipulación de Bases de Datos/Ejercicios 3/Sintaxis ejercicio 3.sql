*****
Ejercicios de Ampliacion 05, INSERT, UPDATE Y DELETE
*****

[]

NOMBRE: JERÓNIMO SILVA MULERO

[]


CONNECT SYSTEM
		MANAGER

CREATE USER AMPLIACION IDENTIFIED BY AMPLIACION QUOTA 5M ON USERS;

GRANT CONNECT, RESOURCE TO AMPLIACION;

GRANT CREATE SYNONYM TO AMPLIACION;

GRANT CREATE VIEW TO AMPLIACION;

CONNECT AMPLIACION
        AMPLIACION
		
Ejecutar el Script 
START C:\datos05.sql


Tablas ALUM, NUEVOS y ANTIGUOS-----------------------------------------------------------------------------------------------------------------

1 Dadas las tablas ALUM y NUEVOS, insertar en la tabla ALUM los alumnos nuevos.

NUEVOS
INSERT INTO ALUM (NOMBRE, EDAD, LOCALIDAD) VALUES ('JUAN',18,'COSLADA');
INSERT INTO ALUM (NOMBRE, EDAD, LOCALIDAD) VALUES ('MAITE',15,'ALCALA');
INSERT INTO ALUM (NOMBRE, EDAD, LOCALIDAD) VALUES ('SOFIA',14,'ALCALA');
INSERT INTO ALUM (NOMBRE, EDAD, LOCALIDAD) VALUES ('ANA',17,'ALCALA');
INSERT INTO ALUM (NOMBRE, EDAD, LOCALIDAD) VALUES ('ERNESTO',21,'MADRID');

ANTIGUOS
INSERT INTO ALUM (NOMBRE, EDAD, LOCALIDAD) VALUES ('MARIA',20,'MADRID');
INSERT INTO ALUM (NOMBRE, EDAD, LOCALIDAD) VALUES ('ERNESTO',21,'MADRID');
INSERT INTO ALUM (NOMBRE, EDAD, LOCALIDAD) VALUES ('ANDRES',26,'LAS ROZAS');
INSERT INTO ALUM (NOMBRE, EDAD, LOCALIDAD) VALUES ('IRENE',24,'LAS ROZAS');


2 Borrar de la tabla ALUM los alumnos de la tabla ANTIGUOS.

DELETE FROM ALUM  
WHERE NOMBRE IN(SELECT NOMBRE
                 FROM ANTIGUOS                                  
				 INTERSECT SELECT NOMBRE 
				           FROM ALUM); 


Tablas EMPLE y DEPART---------------------------------------------------------------------------------------------------------------------------

3 Insertar un empleado de apellido 'SAAVEDRA' con número 2000. La fecha de alta será la actual del sistema, 
el SALARIO el mismo del empleado 'SALA' más el 20% y el resto de datos igual que 'SALA'.

INSERT INTO EMPLE30 (SELECT 2000, 'SAAVEDRA', OFICIO, DIR, SYSDATE, SALARIO+SALARIO*20/100, COMISION, DEPT_NO     
FROM EMPLE30  
WHERE APELLIDO = 'SALA');


4 Modificar el número de departamento de 'SAAVEDRA'. El nuevo departamento será aquel donde hay más empleados cuyo OFICIO se 'EMPLEADO'.

 UPDATE EMPLE30 SET DEPT_NO = (SELECT DEPT_NO 
                               FROM EMPLE30 
							   WHERE OFICIO ='EMPLEADO'    
							   GROUP BY DEPT_NO                          
							   HAVING COUNT(*)= (SELECT MAX(COUNT(*)) 
							                   FROM EMPLE30
                                               WHERE OFICIO ='EMPLEADO'  
									           GROUP BY DEPT_NO))    
											   WHERE APELLIDO = 'SAAVEDRA';

																	   
5 Borrar todos los departamentos de la tabla DEPART para los cuales no existan empleados en EMPLE. 

DELETE FROM DEPART            
WHERE DEPT_NO=(SELECT DEPT_NO 
               FROM EMPLE30     
			   GROUP BY DEPT_NO
			   HAVING COUNT(*)=0);


Tablas PERSONAL, PROFESORES y CENTROS---------------------------------------------------------------------------------------------------------------
6 Modificar el nº de plazas de la tabla CENTROS con un valor igual a la mitad en aquellos centros con menos de dos profesores.

UPDATE CENTROS SET NUM_PLAZAS = NUM_PLAZAS/2       
               WHERE COD_CENTRO  IN (SELECT COD_CENTRO 
						            FROM PROFESORES
								    GROUP BY COD_CENTRO  
								    HAVING COUNT(*)<2);

											   
7 Eliminar los centros que no tengan personal.

DELETE CENTROS WHERE COD_CENTRO IN (SELECT COD_CENTRO 
                                    FROM CENTROS  MINUS SELECT COD_CENTRO FROM PERSONAL);


8 Añadir un nuevo profesor en el centro o en los centros cuyo nº de administrativos sea 1 en la especialidad 'IDIOMA', con DNI 8790055 y de
nombre 'Clara Salas'.

INSERT INTO PROFESORES    (COD_CENTRO, DNI, APELLIDOS, ESPECIALIDAD)  
SELECT COD_CENTRO, 8790055, 'CLARA SALAS', 'IDIOMA'   
FROM CENTROS   
WHERE COD_CENTRO IN (SELECT COD_CENTRO
                     FROM PERSONAL          
					 WHERE FUNCION = 'ADMINISTRATIVO' 
					 GROUP BY COD_CENTRO       
					 HAVING COUNT(*)=1);


9 Borrar el personal que esté en centros de menos de 300 plazas y con menos de dos profesores.

 DELETE FROM PERSONAL WHERE COD_CENTRO IN (SELECT COD_CENTRO 
                                           FROM CENTROS 
										   WHERE NUM_PLAZAS < 300 AND COD_CENTRO IN (SELECT COD_CENTRO 
										                                             FROM PROFESORES  
																					 GROUP BY COD_CENTRO
																					 HAVING COUNT(*)<2));


10 Borrar a los profesores que estén en la tabla PROFESORES y no estén en la tabla PERSONAL.

 DELETE FROM PROFESORES WHERE DNI NOT IN (SELECT DNI 
                                          FROM PERSONAL 
										  WHERE FUNCION = 'PROFESOR'); 
