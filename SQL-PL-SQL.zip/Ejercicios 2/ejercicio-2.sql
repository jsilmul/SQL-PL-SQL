1 ¿Cuál sería la salida al ejecutar estas funciones?

ABS(146)	     ABS(-30)	        CEIL(2)	         CEIL(1.3)
CEIL(-2.3)	     CEIL(-2)	        FLOOR(-2)	     FLOOR(-2.3)
FLOOR(2)	     FLOOR(1.3)	        MOD(22,23)	     MOD(10,3)
POWER(10,0)	     POWER(3,2)	        POWER(3,-1)	     ROUND(33.67)
ROUND(-33.67,2)	 ROUND(-33.67,-2)	ROUND(-33.27,1)	 ROUND(-33.27,-1)
TRUNC(67.232)	 TRUNC(67.232,-2)	TRUNC(67.232,2)	 TRUNC(67.58,1)

--------------------------------------------------------------------------------------------------

ABS(146)=146             ABS(-30)=30           CEIL(2)=2                CEIL(1.3)= 2

CEIL(-2.3)=-2            CEIL(-2)=-2           FLOOR(-2)=-2             FLOOR(-2.3)=-3

FLOOR(2)=2               FLOOR(1.3)=1          MOD(22,23)=22            MOD(10,3)=1

POWER(10,0)=1            POWER(3,2)=9          POWER(3,-1)=,33333       ROUND(33.67)= 34     

ROUND(-33.67,2)= -33,67  ROUND(-33.67,-2)=0    ROUND(-33.27,1)= -33,3   ROUND(-33.27,-1)=-30

TRUNC(67.232)= 67        TRUNC(67.232,-2)=0    TRUNC(67.232,2)= 67,23   TRUNC(67.58,1)= 67,5







2 A partir de la tabla EMPLE, visualizar cuantos apellidos de empleados empiezan por la letra 'A'.

SELECT COUNT(*) 
FROM EMPLE 
WHERE APELLIDO LIKE 'A%';
 

3 Dada la tabla EMPLE, obtén el sueldo medio, el nº de comisiones no nulas, el máximo sueldo y el mínimo sueldo de los empleados del departamento 30. 
Emplear el formato adecuado para la salida de las cantidades numéricas.

SELECT AVG (SALARIO), COUNT (COMISION), MAX (SALARIO), MIN(SALARIO)
FROM EMPLE
WHERE DEPT_NO = 30;

SELECT TO_CHAR (AVG (SALARIO),'9G999G999D99'), COUNT (COMISION), TO_CHAR (MAX (SALARIO), '9G999G999'), TO_CHAR (MIN (SALARIO), '9G999G999')
FROM EMPLE
WHERE DEPT_NO = 30;
				  
				  
4 Contar los temas de LIBRERIA cuyo tema tenga, por lo menos una 'a'.

SELECT COUNT (TEMA)
FROM LIBRERIA
WHERE UPPER (TEMA) LIKE '%a%';


5 Visualiza los temas con mayor número de ejemplares de la tabla LIBRERIA y que tengan, al menos, una 'e' (pueden ser un tema o varios).

SELECT TEMA
FROM LIBRERIA
WHERE EJEMPLARES = (SELECT MAX (EJEMPLARES)
                    FROM LIBRERIA)
                    AND TEMA LIKE '%e%';
					
SELECT TEMA, EJEMPLARES
FROM LIBRERIA
WHERE UPPER (TEMA) LIKE '%e%'
AND EJEMPLARES = (SELECT MAX (EJEMPLARES)
                  FROM LIBRERIA
				  WHERE UPPER (TEMA) LIKE '%e%');


6 Visualiza el nº de estantes diferentes que hay en la tabla LIBRERIA.

SELECT COUNT(DISTINCT ESTANTE)
FROM LIBRERIA;


7 Visualiza el nº de estantes distintos que hay en la tabla LIBRERIA de aquellos temas que contienen, al menos, una 'e'.

SELECT COUNT(DISTINCT ESTANTE)
FROM LIBRERIA
WHERE TEMA LIKE '%e%';

SELECT COUNT (DISTINCT ESTANTE)
FROM LIBRERIA
WHERE UPPER (TEMA) LIKE '%e%';


8 Dada la tabla MISTEXTOS, ¿qué sentencia SELECT se debe ejecutar para tener este resultado?
RESULTADO
----------------------------------------
METODOLOGÍA DE LA PROGRAMACIÓN-^-^-^-^-^
INFORMÁTICA BÁSICA-^-^-^-^-^-^-^-^-^-^-^
SISTEMAS OPERATIVOS-^-^-^-^-^-^-^-^-^-^-
SISTEMAS DIGITALES-^-^-^-^-^-^-^-^-^-^-^
MANUAL DE C-^-^-^-^-^-^-^-^-^-^-^-^-^-^-

SELECT RPAD(RTRIM(RTRIM(LTRIM(TITULO,'"'),'"'),'.'), 40, '-^')
FROM MISTEXTOS; 


9 Visualiza los títulos de la tabla MISTEXTOS sin los caracteres punto y comillas, y en minúsculas, de dos maneras diferentes.

SELECT LOWER(REPLACE(REPLACE(TITULO,'"'),'.')) 
FROM MISTEXTOS;	

SELECT LOWER(TRANSLATE(TITULO,'A".','A')) 
FROM MISTEXTOS;	



10 Dada la tabla LIBROS, escribe la sentencia SELECT que visualice dos columnas, una con el AUTOR y otra con el apellido del autor.

SELECT AUTOR, SUBSTR (AUTOR,1, INSTR (AUTOR, ',') -1)
FROM LIBROS;



11 Escribe la sentencia SELECT que visualice dos columnas, una con el AUTOR y otra columna con el nombre del autor (sin el apellido) de la tabla LIBROS.


SELECT AUTOR, SUBSTR (AUTOR, INSTR (AUTOR, ',') +2)
FROM LIBROS;


12 A partir de la tabla LIBROS, realiza una consulta que visualice en una columna, primero el nombre del autor y, luego, el apellido.

SELECT SUBSTR(AUTOR,INSTR(AUTOR,',',1)+1),SUBSTR(AUTOR,0,INSTR(AUTOR,',',1)-1 )
FROM LIBROS;

SELECT SUBSTR (AUTOR, INSTR (AUTOR, ',') +2)
|| ''
|| SUBSTR (AUTOR, 1, INSTR (AUTOR, ',')-1)
AS NOMBRE
FROM LIBROS;


13 A partir de la tabla LIBROS, realiza una consulta que aparezcan los títulos ordenados por su nº de caracteres.

SELECT TITULO
FROM LIBROS
ORDER BY LENGTH (TITULO); 


14 A partir de la tabla NACIMIENTOS, realiza una consulta que obtenga las columnas NOMBRE, FECHANAC, FECHA_FORMATEADA donde FECHA_FORMATEADA 
tiene el siguiente formato: "Nació el 12 de mayo de 1982".

 
SELECT NOMBRE, FECHANAC, TO_CHAR (FECHANAC, '"Nació el dia "dd" de "month" de "yyyy"') AS FECHA_FORMATEADA
FROM NACIMIENTOS;


15 Dada la tabla LIBRERIA, haz una consulta que visualice el tema, el último carácter del tema que no sea blanco y 
el nº de caracteres de tema (sin contar los blancos de la derecha) ordenados por tema.

SELECT TEMA, SUBSTR(TEMA,INSTR(TEMA,' ')-1),INSTR(TEMA,' ')-1
FROM LIBRERIA
ORDER BY TEMA;

SELECT TEMA, SUBSTR (TEMA, LENGTH (RTRIM(TEMA)), 1) "Ultima Letra", LENGTH(RTRIM(TEMA)) "Longitud"
FROM LIBRERIA
ORDER BY TEMA;


16 A partir de la tabla NACIMIENTOS, realiza una consulta que muestre NOMBRE seguido de su fecha de nacimiento formateada (quita los blancos de nombre).


SELECT RTRIM(NOMBRE)
|| ' '
|| TO_CHAR (FECHANAC, '"Nacio el "dd" de "month" de "yyyy')
FROM NACIMIENTOS;


17 Convierte la cadena '01072012' a fecha y visualiza el nombre del mes en mayúsculas (utiliza la tabla DUAL).

SELECT TO_CHAR (TO_DATE('01072012', 'DD/MM/YYYY'), 'DD/MONTH/YYYY'), TO_DATE('01072012', 'DD/MM/YYYY')
FROM DUAL;



18 Visualiza aquellos temas de la tabla LIBRERIA cuyos ejemplares sean 7 con el nombre de tema 'SEVEN'; el resto de temas que no tengan 7 ejemplares 
se visualizará como están. Ejemplo:

TEMA            EJEMPLARES CODIGO
--------------- ---------- ---------------
Informática             15 Informática
Economía                10 Economía
Deportes                 8 Deportes
Filosofía                7 SEVEN
Dibujo                  10 Dibujo
Biología                11 Biología
Geología                 7 SEVEN

SELECT TEMA, EJEMPLARES,DECODE(EJEMPLARES,7,DECODE(TEMA,TEMA,'SEVEN',TEMA),TEMA) CODIGO
FROM LIBRERIA;


19 A partir de la tabla EMPLE, obtener el apellido de los empleados que lleven más de 15 años trabajando.

SELECT APELLIDO 
FROM EMPLE 
WHERE 2004 – TO_NUMBER(TO_CHAR(FECHA_ALT,’YYYY’))>15;


20 Selecciona el apellido de los empleados que llevan más de 18 años trabajando en el departamento 'VENTAS'.

SELECT APELLIDO, FECHA_ALT, TRUNC(MONTHS_BETWEEN (SYSDATE, FECHA_ALT)/12) ANTIGUEDAD
FROM EMPLE
WHERE DEPT_NO = (SELECT DEPT_NO
                 FROM DEPART
				 WHERE DNOMBRE = 'VENTAS')
				 AND MONTHS_BETWEEN(SYSDATE, FECHA_ALT)/12 > 18;


21 Visualiza el apellido, el salario, y el nº de departamento de los empleados cuyo salario sea el mayor de su departamento.

SELECT APELLIDO, SALARIO , DEPT_NO 
FROM EMPLE E 
WHERE SALARIO IN (SELECT MAX(SALARIO) 
				  FROM EMPLE 
				  WHERE DEPT_NO=E.DEPT_NO);


22 Visualiza el apellido, el salario, y el nº de departamento de los empleados cuyo salario supere a la media de su departamento.

SELECT APELLIDO,SALARIO,DEPT_NO 
FROM EMPLE E 
WHERE SALARIO>(SELECT AVG(SALARIO) 
			   FROM EMPLE 
			   WHERE DEPT_NO=E.DEPT_NO);