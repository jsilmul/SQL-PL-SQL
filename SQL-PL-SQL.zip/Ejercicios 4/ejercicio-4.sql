**JARDINERÍA**

Sobre la base da datos de jardinería:

----------------------Multitabla

---1. Sacar un listado con el nombre de cada cliente y el nombre y apellido de su representante de ventas.

  
---2. Sacar un listado con el nombre de cada cliente y el nombre de su representante y la oficina (CIUDAD) a la que pertenece dicho representante


3. Listar las ventas totales de los productos que hayan facturado más de 3000 euros. Se mostrará el nombre, unidades vendidas y total facturado

SELECT productos.nombre, SUM(detallepedidos.cantidad), SUM(detallepedidos.cantidad * detallepedidos.preciounidad)
FROM productos, detallepedidos
WHERE productos.codigoproducto = detallepedidos.codigoproducto
GROUP BY productos.codigoproducto
HAVING SUM (detallepedidos.cantidad * detallepedidos.preciounidad) > 30;


4. Listar la dirección de las oficinas que tengan clientes en Fuenlabrada.

5. Obtener un listado con los nombres de los empleados más los nombres de sus jefes


-------6. Obtener el nombre de los clientes a los que no se les ha entregados a tiempo un pedido


-----------------------Funciones agrupadas
    
-------7. Obtener el código de oficina y la ciudad donde hay oficinas.
 



-----------------8. Sacar cuántos empleados hay en la compañía


----------------9. Sacar cuántos clientes tiene cada país



10. Sacar cuál fue el pago medio en 2009 (PISTA: usar la función YEAR de MySql)

11. Sacar cuántos pedidos están en cada estado ordenado descendentemente por el número de pedido



----------------12. Sacar el precio más caro y el más barato de los productos





13. Obtener las gamas de productos que tengan más de 100 productos  (en la tabla productos)

14. Obtener el precio medio de proveedor de PRODUCTOS agrupando por proveedor de los proveedores que no empiecen por M y visualizando 
sólo los que la media es mayor de 15. 



---------LISTADO DE LOS NOMBRES DE CLIENTE JUNTO CON LA CANTIDAD DE PEDIDOS REALIZADOS




---------LISTADO DE EMPLEADOS CUYO PUESTO SEA REPRESENTANTE VENTAS (NOMBRE, APELLIDO1)



---------LISTADO DE CUANTOS EMPLEADOS CUYO PUESTO SEA REPRESENTANTE VENTAS HAY



----------NOMBRE Y CORRREO ELECTRÓNICO DE LOS EMPLEADOS QUE CONTENGAN 'JARDINERIA' 




----------------------CUANTOS CORREOS ELECTRÓNICOS HAY EN EL DOMINIO DE jardineria.es

