---------------------------Consultas SQL

---------------------------Base de datos de ciclismo

---------------------------Jerónimo/Silva/Mulero


Tenemos una base de datos dedicada a gestionar toda la información de una competición ciclista,con las tablas ciclista, equipo, etapa, llevar,
maillot y puerto. Necesitamos realizas consultas para obtener las siguientes informaciones:



1. Obtener el código, el tipo, el color y el premio de todos los maillots que hay.

SELECT CODIGO, TIPO, COLOR, PREMIO FROM MAILLOT;

SET LINE 150;


 
2. Obtener el dorsal y el nombre de los ciclistas cuya edad sea menor o igual que 25 años.

SELECT NOMBRE, DORSAL FROM CICLISTA WHERE EDAD <= 25;



3. Obtener el nombre y la altura de todos los puertos de categoría ‘E’ (Especial).

SELECT NOMPUERTO, ALTURA FROM PUERTO WHERE CATEGORIA = 'E'; 



4. Obtener el valor del atributo netapa de aquellas etapas con salida y llegada en la misma ciudad.

SELECT SALIDA, NETAPA, FROM ETAPA WHERE SALIDA = LLEGADA;



5. ¿Cuántos ciclistas hay?.

SELECT COUNT (DORSAL) FROM CICLISTA;



6. ¿Cuántos ciclistas hay con edad superior a 25 años?

SELECT COUNT (DORSAL) FROM CICLISTA WHERE EDAD > 25;



7. ¿Cuántos equipos hay?

SELECT COUNT (NOMEQ) FROM EQUIPO;



8. Obtener la media de edad de los ciclistas.

SELECT AVG (EDAD) FROM CICLISTA;



9. Obtener la altura mínima y máxima de los puertos de montaña.

SELECT MIN(ALTURA), MAX(ALTURA) FROM PUERTO;



10. Obtener la altura máxima de los puertos por categoría.

SELECT MAX(ALTURA), CATEGORIA  FROM PUERTO GROUP BY CATEGORIA;



11. Obtener la media de edad de ciclistas para cada equipo.

SELECT NOMEQ, AVG (EDAD) FROM CICLISTA GROUP BY NOMEQ;



12. Obtener los equipos cuya media de edad es mayor de 30.

SELECT NOMEQ , AVG (EDAD) > 30
FROM CICLISTA 
GROUP BY NOMEQ;



-----------------------------------------------------------------------Consultas sobre varias tablas



13. Obtener el nombre y la categoría de los puertos ganados por ciclistas del equipo ‘Banesto’.

SELECT NOMPUERTO, CATEGORIA FROM PUERTO WHERE DORSAL IN (SELECT DORSAL FROM CICLISTA WHERE NOMEQ = 'BANESTO');



14. Obtener el nombre de cada puerto indicando el número (netapa) y los kilómetros de la etapa en la que se encuentra el puerto.

SELECT NOMPUERTO, NETAPA, KM FROM PUERTO P, ETAPA E WHERE P.NETAPA = E.NETAPA;



15. Obtener el nombre y el director de los equipos a los que pertenezca algún ciclista mayor de 33 años.

SELECT NOMEQ, DESCRIPCION FROM EQUIPO WHERE NOMEQ IN (SELECT NOMEQ FROM CICLISTA WHERE EDAD > 33);



16. Obtener el nombre de los ciclistas con el color de cada maillot que hayan llevado.

SELECT DISTINCT NOMBRE, COLOR FROM CICLISTA C, MAILLOT M, LLEVAR L WHERE C.DORSAL = L.DORSAL AND M.CODIGO = L.CODIGO;



17.Obtener pares de nombre de ciclista y número de etapa tal que ese ciclista haya ganado esa etapa habiendo llevado el maillot de color ‘Amarillo’ 
al menos una vez.

SELECT C.NOMBRE, E.NETAPA FROM CICLISTA C, ETAPA E WHERE C.DORSAL = E.DORSAL AND C.DORSAL IN (SELECT DORSAL FROM LLEVAR L WHERE L.CODIGO = 
(SELECT CODIGO FROM MAILLOT WHERE COLOR = 'AMARILLO') AND L.NETAPA < E.NETAPA);
																						



 -------------------------------------------------------------------Consultas con subconsultas 

 
18. Obtener el valor del atributo netapa y la ciudad de salida de aquellas etapas que no tengan puertos de montaña.

SELECT NETAPA FROM ETAPA E WHERE SALIDA != (SELECT LLEGADA FROM ETAPA E2 WHERE E2.NETAPA = (E.NETAPA -1));



19. Obtener la edad media de los ciclistas que han ganado alguna etapa. 

SELECT ROUND(AVG(EDAD),2) FROM CICLISTA WHERE DORSAL IN (SELECT DORSAL FROM ETAPA);



20. Selecciona el nombre de los puertos con una altura superior a la altura media de todos los puertos. 

SELECT NOMPUERTO FROM PUERTO WHERE ALTURA > (SELECT AVG (ALTURA) FROM PUERTO);



21. Obtener el nombre de la ciudad de salida y de llegada de las etapas donde estén los puertos con mayor pendiente.

SELECT SALIDA, LLEGADA FROM ETAPA WHERE NETAPA IN (SELECT NETAPA FROM PUERTO WHERE PENDIENTE = (SELECT MAX (PENDIENTE)FROM PUERTO));



22. Obtener el dorsal y el nombre de los ciclistas que han ganado los puertos de mayor altura.

SELECT DORSAL, NOMBRE FROM CICLISTA WHERE DORSAL IN (SELECT DORSAL FROM PUERTO WHERE ALTURA = (SELECT MAX (ALTURA) FROM PUERTO));



23. Obtener el nombre del ciclista más joven. 

SELECT NOMBRE FROM CICLISTA WHERE EDAD = (SELECT MIN (EDAD) FROM CICLISTA);



24. Obtener el nombre del ciclista más joven que ha ganado al menos una etapa.

SELECT NOMBRE FROM CICLISTA WHERE EDAD = (SELECT MIN (EDAD) FROM CICLISTA WHERE DORSAL IN (SELECT DORSAL FROM ETAPA)) AND DORSAL IN (SELECT DORSAL 
																																	 FROM ETAPA);



25. Obtener el nombre de los ciclistas que han ganado más de un puerto.

SELECT C.NOMBRE, COUNT (P.DORSAL) FROM PUERTO P RIGHT OUTER JOIN CICLISTA C ON C.DORSAL = P.DORSAL GROUP BY C.NOMBRE HAVING COUNT (*)>1;




--------------------------------------------------------- Consultas con cuantificación universal (CON NOT EXISTS O NOT IN)


26. Obtener el valor del atributo netapa de aquellas etapas tales que todos los puertos que están en ellas tienen más de 700 metros de altura.

SELECT NETAPA FROM ETAPA WHERE NETAPA NOT IN (SELECT NETAPA FROM PUERTO WHERE ALTURA < 700) AND NETAPA IN (SELECT NETAPA FROM PUERTO);



27. Obtener el nombre y el director de los equipos tales que todos sus ciclistas son mayores de 26 años. 

SELECT NOMEQ, DESCRIPCION FROM EQUIPO WHERE NOMEQ NOT IN (SELECT NOMEQ FROM CICLISTA WHERE EDAD < 26);



28. Obtener el dorsal y el nombre de los ciclistas tales que todas las etapas que han ganado tienen más de 170 km (es decir que sólo han ganado 
etapas de más de 170 km). 

SELECT DORSAL, NOMBRE FROM CICLISTA WHERE DORSAL NOT IN (SELECT DORSAL FROM ETAPA WHERE KM < 170) AND DORSAL IN (SELECT DORSAL FROM ETAPA);



29. Obtener el nombre de los ciclistas que han ganado todos los puertos de una etapa y además han ganado esa misma etapa. 

SELECT NOMBRE FROM CICLISTA C WHERE C.DORSAL IN (SELECT DORSAL FROM ETAPA E WHERE DORSAL = ALL (SELECT DORSAL FROM PUERTO P WHERE NETAPA = E.NETAPA)
AND DORSAL IN (SELECT DORSAL FROM PUERTO P WHERE NETAPA = E.NETAPA));



30. Obtener el nombre de los equipos tales que todos sus corredores han llevado algún maillot o han ganado algún puerto. 

SELECT NOMEQ FROM EQUIPO WHERE NOMEQ NOT IN(SELECT NOMEQ FROM CICLISTA WHERE DORSAL NOT IN(SELECT DORSAL FROM LLEVAR) AND DORSAL NOT IN(SELECT DORSAL
																																		FROM PUERTO));



31. Obtener el código y el color de aquellos maillots que sólo han sido llevados por ciclistas de un mismo equipo. 

SELECT CODIGO, COLOR FROM MAILLOT M, CICLISTA C, LLEVAR L WHERE L.DORSAL = C.DORSAL AND M.CODIGO = L.CODIGO GROUP BY CODIGO,COLOR 
																											HAVING COUNT (DISTINCT NOMEQ)=1;



32. Obtener el nombre de aquellos equipos tal que sus ciclistas sólo hayan ganado puertos de 1ª categoría. 

SELECT DISTINCT NOMEQ FROM CICLISTA C WHERE NOT EXISTS (SELECT DORSAL 
														FROM PUERTO P WHERE P.DORSAL IN (SELECT DORSAL 
																						 FROM CICLISTA C2 WHERE C2.NOMEQ = C.NOMEQ) 
AND CATEGORIA !=1) AND EXISTS (SELECT DORSAL 
							   FROM PUERTO P WHERE P.DORSAL IN (SELECT DORSAL 
															    FROM CICLISTA C3 WHERE C3.NOMEQ = C.NOMEQ) AND CATEGORIA = 1);																																					  )
																																   




-------------------------------------------------------Consultas agrupadas


33. Obtener el valor del atributo netapa de aquellas etapas que tienen puertos de montaña indicando cuántos tiene.

SELECT NETAPA, COUNT(*) FROM ETAPA E, PUERTO P WHERE E.NETAPA = P.NETAPA GROUP BY E.NETAPA;

 

34. Obtener el nombre de los equipos que tengan ciclistas indicando cuántos tiene cada uno. 

SELECT E.NOMEQ, COUNT(C.NOMEQ) FROM CICLISTA C RIGHT OUTER JOIN EQUIPO E ON E.NOMEQ = C.NOMEQ GROUP BY E.NOMEQ;



35. Obtener el nombre de todos los equipos indicando cuántos ciclistas tiene cada uno. 

SELECT E.NOMEQ, COUNT (C.NOMEQ) FROM CICLISTA C RIGHT OUTER JOIN EQUIPO E ON E.NOMEQ = C.NOMEQ GROUP BY E.NOMEQ;



36. Obtener el director y el nombre de los equipos que tengan más de 3 ciclistas y cuya edad media sea inferior o igual a 30 años.

SELECT E.NOMEQ, DESCRIPCION FROM EQUIPO E, CICLISTA C WHERE E.NOMEQ = C.NOMEQ GROUP BY E.NOMEQ HAVING COUNT (*)>3 AND AVG (EDAD)<= 30; 



37. Obtener el nombre de los ciclistas que pertenezcan a un equipo que tenga más de cinco corredores y que hayan ganado alguna etapa indicando cuántas
etapas ha ganado. 

SELECT C.NOMBRE, COUNT(*) FROM CICLISTA C, EQUIPO E, ETAPA ET 
                          WHERE C.NOMEQ = E.NOMEQ AND C.DORSAL=ET.DORSAL AND E.NOMEQ IN (SELECT E.NOMEQ
																						 FROM EQUIPO E, CICLISTA C WHERE E.NOMEQ=C.NOMEQ
																												   GROUP BY E.NOMEQ 
																												   HAVING COUNT (*)>5) GROUP BY C.NOMBRE;



38. Obtener el nombre de los equipos y la edad media de sus ciclistas de aquellos equipos que tengan la media de edad máxima de todos los equipos. 

CREATE VIEW EDADESMEDIAS AS SELECT E.NOMEQ, AVG (EDAD) AS EDADMEDIA FROM CICLISTA C, EQUIPO E WHERE C.NOMEQ = E.NOMEQ GROUP BY E.NOMEQ;

SELECT E.NOMEQ, AVG(EDAD) FROM CICLISTA C, EQUIPO E WHERE C.NOMEQ = E.NOMEQ GROUP BY E.NOMEQ HAVING AVG(EDAD)=(SELECT MAX(EDADMEDIA)
                                                                                                               FROM EDADESMEDIAS);



39. Obtener el director de los equipos cuyos ciclistas han llevado más días maillots de cualquier tipo. Nota: cada tupla de la relación llevar indica
que un ciclista ha llevado un maillot un día

CREATE VIEW NUMDIASMAILLOTPOREQUIPO AS SELECT NOMEQ, COUNT(*) AS NUMERODIAS FROM CICLISTA C, LLEVAR L WHERE C.DORSAL=L.DORSAL GROUP BY NOMEQ;

SELECT DESCRIPCION FROM EQUIPO WHERE NOMEQ IN (SELECT NOMEQ FROM CICLISTA C, LLEVAR L WHERE C.DORSAL=L.DORSAL GROUP BY NOMEQ HAVING COUNT(*)=
                                                                                        (SELECT MAX(NUMERODIAS) FROM NUMDIASMAILLOTPOREQUIPO));




-------------------------------------------------------------------Consultas generales



40. Obtener el código y el color del maillot que ha sido llevado por algún ciclista que no ha ganado ninguna etapa.

SELECT CODIGO, COLOR FROM MAILLOT WHERE CODIGO IN (SELECT CODIGO FROM LLEVAR WHERE DORSAL NOT IN (SELECT DORSAL FROM ETAPA));



41.Obtener el valor del atributo netapa, la ciudad de salida y la ciudad de llegada de las etapas de más de 190km y que tengan por lo menos 2 puertos. 

SELECT NETAPA, SALIDA, LLEGADA FROM ETAPA WHERE KM > 190 AND NETAPA IN (SELECT NETAPA FROM PUERTO GROUP BY NETAPA HAVING COUNT(*)>=2);

SET LINE 150;



42. Obtener el dorsal y el nombre de los ciclistas que no han llevado todos los maillots que ha llevado el ciclista de dorsal 20 

SELECT C.DORSAL, NOMBRE FROM CICLISTA C WHERE EXISTS(SELECT CODIGO FROM LLEVAR WHERE DORSAL=20 AND CODIGO NOT IN (SELECT CODIGO 
                                                                                                                  FROM LLEVAR L 
																												  WHERE L.DORSAL=C.DORSAL));



43. Obtener el dorsal y el nombre de los ciclistas que han llevado al menos un maillot de los que ha llevado el ciclista de dorsal 20. 

SELECT C.DORSAL, NOMBRE FROM CICLISTA C WHERE DORSAL IN (SELECT DORSAL FROM LLEVAR WHERE CODIGO IN (SELECT CODIGO FROM LLEVAR WHERE DORSAL=20));



44. Obtener el dorsal y el nombre de los ciclistas que no han llevado ningún maillot de los que ha llevado el ciclista de dorsal 20. 

SELECT C.DORSAL, NOMBRE FROM CICLISTA C WHERE DORSAL NOT IN (SELECT DORSAL FROM LLEVAR WHERE CODIGO IN (SELECT CODIGO FROM LLEVAR WHERE DORSAL=20));



45. Obtener el dorsal y el nombre de los ciclistas que han llevado todos los maillots que ha llevado el ciclista de dorsal 20. 

SELECT C.DORSAL, NOMBRE FROM CICLISTA C WHERE EXISTS (SELECT CODIGO FROM LLEVAR WHERE DORSAL=20 AND CODIGO IN (SELECT CODIGO 
																											   FROM LLEVAR L WHERE L.DORSAL=C.DORSAL));



46. Obtener el dorsal y el nombre de los ciclistas que han llevado exactamente los mismos maillots que ha llevado el ciclista de dorsal 20.

SELECT C.DORSAL, NOMBRE FROM CICLISTA C WHERE NOT EXISTS (SELECT CODIGO 
                                                          FROM LLEVAR WHERE DORSAL = 20 AND CODIGO NOT IN(SELECT CODIGO 
																				                         FROM LLEVAR L 
																				                         WHERE L.DORSAL=C.DORSAL)) AND NOT EXISTS(SELECT CODIGO 
																													                              FROM LLEVAR L
																													                              WHERE DORSAL=C.DORSAL 
																													                              AND CODIGO NOT IN (SELECT CODIGO
																													                                                 FROM LLEVAR L 
																																		                             WHERE L.DORSAL = 20));
																																									 
																																									 
																																									 
47. Obtener el dorsal y el nombre del ciclista que ha llevado durante más kilómetros un mismo maillot e indicar también el color de dicho maillot. 

CREATE VIEW KMSPORMAILLOT AS SELECT DORSAL, CODIGO, SUM(KM) FROM ETAPA E, LLEVAR L, MAILLOT M WHERE E.NETAPA=L.NETAPA AND M.CODIGO=L.CODIGO 
																													GROUP BY DORSAL, CODIGO;



SELECT DORSAL, CODIGO, COLOR, SUM(KM) FROM ETAPA E, LLEVAR L, MAILLOT M WHERE E.NETAPA=L.NETAPA AND M.CODIGO=L.CODIGO GROUP BY DORSAL, CODIGO, COLOR
																											      HAVING SUM (KM) = (SELECT MAX (KM)
																															     FROM KMSPORMAILLOT);




48. Obtener el dorsal y el nombre de los ciclistas que han llevado tres tipos de maillot menos de los que ha llevado el ciclista de dorsal 1. 


SELECT DORSAL, NOMBRE FROM CICLISTA WHERE DORSAL IN (SELECT DORSAL FROM LLEVAR GROUP BY DORSAL HAVING COUNT(*) + 3 = (SELECT COUNT (DISTINCT CODIGO)
																													  FROM LLEVAR WHERE DORSAL=1));



49. Obtener el valor del atributo netapa y los km de las etapas que tienen puertos de montaña.

SELECT NETAPA, KM FROM ETAPA WHERE EXISTS (SELECT NETAPA FROM PUERTO WHERE NETAPA=NETAPA);

