[]

NOMBRE: JERÓNIMO SILVA MULERO

[]

Gestión de permisos (II)-------------------------------------------------------------------------------------------------------------------------------------------------------------


1. Conéctate como system y otorga privilegios al empleado1 para seleccionar, insertar, borrar y modificar datos de la tabla jugadores del usuario nbaXX de forma que pueda
conceder este permiso a otros usuarios.

CONNECT SYSTEM
        MANAGER

	
[usuario empleado1 ya creado en la relacion de ejercicios anterior]
	
GRANT CONNECT, RESOURCE  TO empleado1;

GRANT CREATE TABLE TO empleado1;

GRANT DROP ANY TABLE TO empleado1;

GRANT ALTER ANY TABLE TO empleado1;	
		
GRANT SELECT ANY TABLE TO empleado1 WITH ADMIN OPTION;

GRANT INSERT ANY TABLE TO empleado1 WITH ADMIN OPTION;
		

[usuario nba11]

CREATE USER nba11 IDENTIFIED BY nba11;

GRANT CONNECT, RESOURCE  TO nba11;

GRANT CREATE TABLE TO nba11;

GRANT DROP ANY TABLE TO nba11;

GRANT ALTER ANY TABLE TO nba11;	
		
GRANT SELECT ANY TABLE TO nba11 WITH ADMIN OPTION;

GRANT INSERT ANY TABLE TO nba11 WITH ADMIN OPTION;



CONNECT empleado1
        empleado1

CONNECT nba11
        nba11
		
		
		
2. Consulta los privilegios sobre objetos asignados al empleado1 (dba_tab_privs).

DESCRIBE DBA_TAB_PRIVS;


3. Conéctate como empleado1 y concede los privilegios seleccionar, insertar, borrar y modificar datos de la tabla jugadores del usuario nbaXX al empleado2 ¿Es posible? ¿Por qué?

CONNECT empleado1
        empleado1



GRANT SELECT, INSERT , DELETE, UPDATE ON jugadores TO empleado2 WITH GRANT OPTION;

Si se puede, si es posible,  dado que se le han concedido permisos a empleado1 para conceder privilegios.



4. Como empleado1 consulta los privilegios que ha concedido y a quien. Explica qué es cada columna (all_tab_privs_made).

CONNECT empleado1
        empleado1
		
DESCRIBE ALL_TAB_PRIVS_MADE;

GRANTEE    -- usuario que recibe privilegios
OWNER      -- dueño de la tabla
TABLE_NAME -- nombre de la tabla a consultar
GRANTOR    -- el usuario que concede los permisos, el usuario administrador
PRIVILEGE  -- privilegios que se le han dado
GRANTABLE  -- indica que el privilegio es otorgado como ADMIN OPTION
HIERARCHY  -- indica que el privilegio es otorgado como HIERARCHY OPTION



5. Como empleado1 consulta los privilegios que tiene concedidos (recibidos) y quién se los ha concedido. Explica qué es cada columna (all_tab_privs_recd).

CONNECT empleado1
        empleado1
		
DESCRIBE ALL_TAB_PRIVS_RECD;

GRANTEE    -- usuario que recibe privilegios
OWNER      -- dueño de la tabla
TABLE_NAME -- nombre de la tabla a consultar
GRANTOR    -- el usuario que concede los permisos, el usuario administrador
PRIVILEGE  -- privilegios que se le han dado
GRANTABLE  -- indica que el privilegio es otorgado como ADMIN OPTION
HIERARCHY  -- indica que el privilegio es otorgado como HIERARCHY OPTION


6. Conéctate como system y consulta los privilegios de objetos del empleado2.

CONNECT SYSTEM
        MANAGER

SELECT * FROM DBA_SYS_PRIVS WHERE GRANTEE = 'EMPLEADO2';



7. Observa quien se los ha concedido (grantor).

SELECT *  FROM DBA_TAB_PRIVS WHERE  GRANTEE = 'EMPLEADO2';



8. Consulta los privilegios de objetos que ha concedido el empleado1.

SELECT *  FROM DBA_TAB_PRIVS WHERE  GRANTOR = 'EMPLEADO1';



9. Como empleado2 consulta los privilegios que ha concedido y a quien.

CONNECT empleado2
        empleado2
		
SELECT * FROM DBA_TAB_PRIVS WHERE  GRANTOR = 'EMPLEADO2';


10. Como empleado2 consulta los privilegios que tiene concedidos (recibidos) y quien se los ha concedido.

CONNECT empleado2
        empleado2
		
DESCRIBE ALL_TAB_PRIVS_RECD;


11. Desde system revoca al empleado1 los privilegios para seleccionar, insertar, borrar y modificar datos de la tabla coches del usuario taller. 
¿Se le ha revocado el permiso de también al empleado2? ¿Por qué?

CONNECT SYSTEM
        MANAGER
	

REVOKE SELECT, INSERT, DELETE, UPDATE ON concesionario.coches11 FROM empleado1;

Si se le han revocado también, porque en cuestión de revocar permisos de objetos, se produce efecto cascada, si se le revocan al usuario empleado1, se le revocan a 
empleado2 también; circunstancia que no ocurre con la revocación de permisos de sistema. 




12. Borra los usuarios empleado1, empleado 2 y empleado3 obligando a que se borren todos los objetos de sus esquemas. 
Recuerda que previamente debes cerrar las sesiones que estos usuarios tuvieran abiertas.

CONNECT SYSTEM
        MANAGER
		
DROP USER empleado1 CASCADE;
DROP USER empleado2 CASCADE;
DROP USER empleado3 CASCADE;