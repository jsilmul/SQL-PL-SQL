[]

NOMBRE: JERÓNIMO SILVA MULERO

[]



Gestión de permisos de Roles

Roles predefinidos------------------------------------------------------------------------------------------------------------------------------------------------------------------

1. Sobre la base de datos Oracle conéctate como usuario system.

CONNECT SYSTEM
        MANAGER
		

		
2. Consulta los roles predefinidos en Oracle.

SELECT * FROM SESSION_ROLES;



3. Consulta los privilegios de sistema concedidos a los roles CONNECT y RESOURCE.
IMPORTANTE: Cuando se asigna el rol RESOURCE a un usuario Oracle internamente también le asigna al usuario el privilegio UNLIMITED TABLESPACE (lo
hace con un trigger, no a través del rol ya que este privilegio no se puede asignar a un rol).
Recuerda que a los usuarios les asignamos en prácticas anteriores el rol RESOURCE. Consulta sus privilegios de sistema.

SELECT PRIVILEGE FROM DBA_SYS_PRIVS WHERE GRANTEE = 'CONNECT';

SELECT PRIVILEGE FROM DBA_SYS_PRIVS WHERE GRANTEE = 'RESOURCE';




4. Consulta los privilegios de sistema concedidos al rol DBA.

SELECT * FROM ROLE_SYS_PRIVS WHERE ROLE = 'DBA';



5. Consulta los privilegios sobre objetos concedidos a los roles CONNECT y RESOURCE.

SELECT PRIVILEGE FROM DBA_TAB_PRIVS WHERE GRANTEE = 'CONNECT';

SELECT PRIVILEGE FROM DBA_TAB_PRIVS WHERE GRANTEE = 'RESOURCE';



6. Consulta los privilegios sobre objetos concedidos al rol DBA.

SELECT PRIVILEGE FROM DBA_TAB_PRIVS WHERE GRANTEE = 'DBA';



Crear roles--------------------------------------------------------------------------------------------------------------------------------------------------------------------

7. Crea el usuario alumno1 con contraseña alumno1.

CREATE ROLE alumno1 IDENTIFIED BY alumno1;



8. Crea el usuario alumno2 con contraseña alumno2.

CREATE ROLE alumno2 IDENTIFIED BY alumno2;



9. Crea el rol alumnos sin contraseña.

CREATE ROLE alumnos NOT IDENTIFIED;



10. Verifica que se ha creado el rol.

SELECT ROLE FROM DBA_ROLES;



Asignar roles a usuarios-----------------------------------------------------------------------------------------------------------------------------------------------------

11. Asigna el rol alumnos a los usuarios alumno1 y alumno2.

GRANT alumnos TO alumno1, alumno2 WITH ADMIN OPTION;



12. Verifica que el rol se ha asignado a los usuarios.

SELECT * FROM ROLE_ROLE_PRIVS;



Asignar privilegios a roles---------------------------------------------------------------------------------------------------------------------------------------------------
Privilegios de sistema

13. Asigna los privilegios de sistema CREATE SESSION, CREATE TABLE y CREATE VIEW al rol alumnos.

GRANT CREATE SESSION TO alumnos WITH ADMIN OPTION;

GRANT CREATE TABLE TO alumnos WITH ADMIN OPTION;

GRANT CREATE VIEW TO alumnos WITH ADMIN OPTION;



14. Verifica que se han asignado los privilegios

SELECT * FROM ROLE_SYS_PRIVS WHERE ROLE = 'ALUMNOS';



15. Establece una conexión como alumno1 y verifica los privilegios de sistema y roles que tiene disponibles en su sesión.
Privilegios sobre objetos.

SELECT * FROM SESSION_PRIVS;

SELECT * FROM SESSION_ROLES;



16. Desde el usuario system asigna los privilegios sobre objetos para consultar e insertar en las tablas jugadores y equipos de usuario nbaxx al rol alumnos.

GRANT SELECT, INSERT ON jugadores TO alumnos;

GRANT SELECT, INSERT ON equipos TO alumnos;



17. Verifica que se han asignado los privilegios.

SELECT * FROM ROLE_TAB_PRIVS WHERE ROLE = 'ALUMNOS';



18. Establece una conexión como alumno1 y verifica los privilegios de objetos y roles que tiene disponibles en su sesión. Comprueba que puede consultar la tabla 
jugadores del usuario taller.

SELECT * FROM SESSION_ROLE;

SELECT * FROM USER_TAB_PRIVS;

SELECT * FROM jugadores;



Revocar privilegios a roles------------------------------------------------------------------------------------------------------------------------------------------------
Privilegios de sistema

19. Revoca el privilegio CREATE VIEW al rol alumnos.

REVOKE CREATE VIEW FROM alumnos;



20. Verifica que se ha revocado el privilegio.

SELECT * FROM ROLE_SYS_PRIVS WHERE ROLE = 'ALUMNOS';



Privilegios sobre objetos--------------------------------------------------------------------------------------------------------------------------------------------------

21. Revoca los privilegios sobre objetos para consultar e insertar en la tablaequipos del usuario nba al rol alumnos.

REVOKE SELECT, INSERT ON jugadores FROM alumnos;

REVOKE SELECT, INSERT ON equipos FROM alumnos;



22. Verifica que se han revocado los privilegios.
Privilegio de un usuario que pertenece a un rol.

SELECT * FROM ROLE_TAB_PRIVS WHERE ROLE = 'ALUMNOS';



23. Revoca el privilegio CREATE TABLE solo al alumno2. ¿Qué problema hay y como solucionarlo?
No es posible porque el usuario tiene el privilegio concedido a través del rol alumnos y no directamente. Habría que quitarle el rol al usuario y (dos posibilidades):

REVOKE CREATE TABLE FROM alumno2;


– Asignarle el resto de privilegios directamente de uno en uno.
– Crear un nuevo rol nuevo a partir del alumno, quitarle el privilegio (CREATE TABLE) al nuevo rol y asignarle el nuevo rol al usuario.



Revocar roles---------------------------------------------------------------------------------------------------------------------------------------------------------------

24. Revoca el rol alumnos a los usuarios alumno1 y alumno2.

REVOKE alumnos FROM alumno1;

REVOKE alumnos FROM alumno2;



25. Verifica que el rol se ha revocado a los usuarios.

SELECT * FROM DBA_ROLES_PRIVS WHERE GRANTEE = 'ALUMNOS';



Borrar roles--------------------------------------------------------------------------------------------------------------------------------------------------------------------

26. Borra el rol alumnos sin contraseña.

DROP ROLE alumnos;



27. Verifica que se ha borrado el rol.

SELECT * FROM DBA_ROLES WHERE ROLE = 'ALUMNOS';



28. Borra los usuarios alumno1 y alumno2 (asegúrate de no tener sesiones abiertas con estos usuarios).

DROP USER alumno1 CASCADE; 

DROP USER alumno2 CASCADE;