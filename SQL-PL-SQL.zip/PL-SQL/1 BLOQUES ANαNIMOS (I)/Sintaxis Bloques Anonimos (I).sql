Programación PL/SQL: Bloques anónimos (I)


[]
NOMBRE: JERÓNIMO SILVA MULERO
[]


1. Crea un bloque PL/SQL que pida al usuario su nombre por teclado y que posteriormente lo visualice de la siguiente forma “El nombre introducido es: NOMBRE.

DECLARE
      v_nombre varchar2(20);
BEGIN
     v_nombre := '&Nombre';
     DBMS_OUTPUT.PUT_LINE('Mi nombre es: ' || v_nombre);
END;



2. Crea un bloque PL/SQL en el que se declaren dos variables que almacenen dos números que se pidan por teclado y se muestre su suma por pantalla.

DECLARE
      v_num1 number(5);
      v_num2 number(5);
BEGIN
     v_num1 := '&Numero1';
     v_num2 := '&Numero2';
     
     DBMS_OUTPUT.PUT_LINE('La suma es: ' || (v_num1 + v_num2) );
END;



3. Crea un bloque PL/SQL que muestre la suma del salario de todos los mecánicos (tienes que hacer uso de %TYPE para declarar una variable).

DECLARE
      --Declaramos la variable
      v_salario mecanicos.salario%TYPE;
BEGIN
     --Obtenemos la suma de los salarios
     SELECT SUM(salario) INTO v_salario FROM mecanicos;
     --Imprimimos por pantalla el resultado
     DBMS_OUTPUT.PUT_LINE('La suma de los salarios es: ' || v_salario);
END;



4. Crea un bloque PL/SQL que muestre el número mecánicos y si no hay mecánicos que muestre por pantalla “No hay mecánicos” .

DECLARE
      v_numeromecanicos mecanicos.DNI%TYPE;
BEGIN
     SELECT COUNT(DNI) INTO v_numeromecanicos FROM mecanicos;
	 IF (v_numeromecanicos = 0) THEN
		DBMS_OUTPUT.PUT_LINE('No hay mecanicos');
	 ELSE 
		DBMS_OUTPUT.PUT_LINE('El numero de mecanicos es: ' || v_numeromecanicos);
	 END IF;
END;



5. Crea un bloque PL/SQL que muestre los datos del mecánico con DNI '1001' (tienes que hacer uso de %ROWTYPE para declarar una variable).

DECLARE
      --Declaramos la variable
      v_datosmec mecanicos%ROWTYPE;
BEGIN
     SELECT * INTO v_datosmec 
     FROM mecanicos 
     WHERE DNI = 1001;
     --Imprimimos por pantalla el resultado
     DBMS_OUTPUT.PUT_LINE('El mecanico con DNI ' || v_datosmec.dni
     || ', su nombre es '      || v_datosmec.nombre
     || ', sus apellidos son ' || v_datosmec.apellidos
     || ', su puesto es '      || v_datosmec.puesto
     || ', su salario es '     || v_datosmec.salario
     || ', su telefono es '    || v_datosmec.telefono
     || ', su parcial es '     || v_datosmec.parcial);
END;



6. Crea un bloque PL/SQL que obtenga el año de fabricación del coche con matrícula 'M3020KY' y muestre por pantalla 'Muy antiguo' si el año es 
menor que 1990, 'Antiguo' si está entre 1990 y 2000, y 'Moderno' si es superior a 2000.

DECLARE
	v_año coches.año_fabricacion%TYPE;
BEGIN
	SELECT año_fabricacion INTO v_año 
	FROM coches 
	WHERE coches.matricula = 'M3020KY';
	IF (v_año < 1990) THEN
		DBMS_OUTPUT.PUT_LINE('Muy antiguo');
	ELSIF v_año BETWEEN 1990 AND 2000 THEN
		DBMS_OUTPUT.PUT_LINE('Antiguo');
	ELSE 
		DBMS_OUTPUT.PUT_LINE('Moderno');
	END IF;
END;




7. Crea un bloque PL/SQL que muestre por pantallas los número de 1 al 10 usando un bucle FOR, los números de 20 al 30 usando
 un bucle WHILE y los números del 40 al 50 usando un bucle LOOP.

DECLARE
      v_i NUMBER;
BEGIN
    FOR v_i IN 1..10 LOOP
	DBMS_OUTPUT.PUT_LINE(v_i);
	END LOOP;
	v_i := 20;
	WHILE v_i <= 30 LOOP
	DBMS_OUTPUT.PUT_LINE(v_i);
	v_i := v_i +1;
	END LOOP;
	v_i := 40;
	LOOP
		DBMS_OUTPUT.PUT_LINE(v_i);
	    v_i := v_i +1;
	    IF v_i > 50 THEN 
		    EXIT;
	    END IF;
	END LOOP;
END;



8. Crea un bloque aumente el 100 el salario de todos los mecánicos cuyo puesto es CHAPA.

DECLARE
	 v_aumento mecanicos.salario%TYPE := 100;
	 v_puesto mecanicos.puesto%TYPE := 'chapa';
BEGIN
	 UPDATE mecanicos SET salario = salario + v_aumento 
	 WHERE puesto = v_puesto;
END;



	  
9. Crea un bloque PL/SQL que que reciba una cadena de texto por teclado y la muestre por pantalla al revés.

DECLARE
--Declaramos las variables de texto
v_texto VARCHAR2(30);
v_texto_reves VARCHAR2(30);
BEGIN
v_texto := '&texto';
DBMS_OUTPUT.PUT_LINE('El texto original es: '|| 'v_texto');
--Damos la vuelta al texto
FOR i IN REVERSE 1..LENGTH(v_texto)
LOOP
	v_texto_reves := v_texto_reves || SUBSTR(v_texto, i, 1);  
END LOOP;
DBMS_OUTPUT.PUT_LINE('El texto al revés es: '|| 'v_texto_reves');
END;



10. Crea un bloque PL/SQL que muestre el número de años completos que hay entre dos fechas (crea dos variables de tipo fecha 
con las fechas que quieras para probar).

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY/MM/DD';

DECLARE 
		v_fecha_1 DATE;
		v_fecha_2 DATE;
		v_años NUMBER(3);
BEGIN
--Inicializar por teclado las variables
v_fecha_1 := '&fecha1';
v_fecha_2 := '&fecha2';

IF (v_fecha_1 < v_fecha_2) THEN
	v_años := (v_fecha_2 - v_fecha_1)/365;
ELSE
	v_años := (v_fecha_1 - v_fecha_2)/365;
END IF;
DBMS_OUTPUT.PUT_LINE('Hay: '|| v_años || ' años de diferencia entre las fechas.');
END;


11. Crea un bloque PL/SQL que inserte dos mecánicos en la tabla coches y que aumente el salario de un mecánico en 100.

DECLARE
--ESTRUCTURA DE MECANICO
	v_datos1 mecanicos%ROWTYPE;
	v_datos2 mecanicos%ROWTYPE;
--VARIABLES DE SALARIO Y DE DNI
	v_salario mecanicos.salario%TYPE := 100;
	v_dni mecanicos.dni%TYPE;
BEGIN
--SE RECOGEN LOS DATOS DEL MECANICO 1
v_datos1.dni := '&dni'; 
v_datos1.apellidos := '&apellidos'; 
v_datos1.nombre := '&nombre'; 
v_datos1.puesto := '&puesto'; 
v_datos1.salario := '&salario'; 
v_datos1.parcial := '&parcial'; 
v_datos1.telefono := '&telefono'; 

INSERT INTO mecanicos VALUES(v_datos1.dni, v_datos1.apellidos, v_datos1.nombre, v_datos1.puesto, v_datos1.salario, v_datos1.parcial, v_datos1.telefono);

--SE RECOGEN LOS DATOS DEL MECANICO 2
v_datos2.dni := '&dni'; 
v_datos2.apellidos := '&apellidos'; 
v_datos2.nombre := '&nombre'; 
v_datos2.puesto := '&puesto'; 
v_datos2.salario := '&salario'; 
v_datos2.parcial := '&parcial'; 
v_datos2.telefono := '&telefono';

INSERT INTO mecanicos VALUES(v_datos2.dni, v_datos2.apellidos, v_datos2.nombre, v_datos2.puesto, v_datos2.salario, v_datos2.parcial, v_datos2.telefono);
	
v_dni := '&dni';
UPDATE mecanicos SET salario = salario + v_salario WHERE dni = v_dni;
	
END;
