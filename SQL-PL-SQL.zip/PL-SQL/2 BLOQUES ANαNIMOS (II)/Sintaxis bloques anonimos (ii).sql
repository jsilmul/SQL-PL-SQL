Programación PL/SQL: Bloques anónimos (II)


[]
NOMBRE: JERÓNIMO SILVA MULERO
[]



1. Bloque anónimo al que se le pasarán dos números y visualice si uno es divisor de otro 
(se utilizará la función MOD(dividendo, divisor) que da el resto de dividir el primer número entre el segundo).


DECLARE 
--Declaramos las variables	
		v_num1  NUMBER(10);
		v_num2  NUMBER(10);
		v_resto NUMBER(10);
BEGIN

---Cogemos los valores por teclado
v_num1 := '&Numero1';
v_num2 := '&Numero2';

--Calculamos el resto
v_resto := MOD (v_num1, v_num2);

--Identificar el resultado y mostrar por pantalla

IF (v_resto = 0) THEN
	DBMS_OUTPUT.PUT_LINE('El número1 si es divisible por el número2');
ELSE 
	DBMS_OUTPUT.PUT_LINE('El número1  no es divisible por el número2');
END IF;

END;

o bien

DECLARE 
--Declaramos las variables	
		v_num1  NUMBER(10);
		v_num2  NUMBER(10);
		v_resto NUMBER(10);
BEGIN

---Cogemos los valores por teclado
v_num1 := '&Numero1';
v_num2 := '&Numero2';

--Calculamos el resto
v_resto := MOD (v_num1, v_num2);

--Identificar el resultado y mostrar por pantalla

IF (v_resto = 0) THEN
	DBMS_OUTPUT.PUT_LINE(v_num1 || ' es divisible entre ' || v_num2);
ELSE 
	DBMS_OUTPUT.PUT_LINE(v_num1 || ' no es divisible entre ' || v_num2);
END IF;

END;
 


2. Visualizar la tabla de multiplicar de un número entre 1 y 10 introducido por teclado.

DECLARE
--Declaramos las variables	
		v_tabla  NUMBER(10);
		v_resultado  NUMBER(10);

BEGIN
--Recogemos el valor por teclado
v_tabla := '&Tabla';

IF (v_tabla > 0 AND v_tabla <= 10) THEN
	--Hacemos un bucle que tiene que dar 10 vueltas
	FOR i IN 1..10 LOOP
	v_resultado := v_tabla * i;
	DBMS_OUTPUT.PUT_LINE(v_tabla || ' x ' || i || ' = ' || v_resultado);
	END LOOP;
ELSE
	DBMS_OUTPUT.PUT_LINE('El número debe estar entre 1 y 10');
END IF;

END;



3. Obtener las tablas de multiplicar de los números del 1 al 10.

DECLARE
--Declaramos la variable	
	v_resultado  NUMBER(10);

BEGIN
  FOR i IN 1..10 LOOP
	DBMS_OUTPUT.PUT_LINE('Tabla del ' || i);
	FOR j IN 1..10 LOOP
	v_resultado := i * j;
	DBMS_OUTPUT.PUT_LINE(i || ' x ' || j || ' = ' || v_resultado);
	END LOOP;
	DBMS_OUTPUT.PUT_LINE('');
  END LOOP;
END;



4. Calcular la suma de los números del 1 al 100.

DECLARE
	v_resultado NUMBER (10) :=0;
    v_contador NUMBER (10) :=0;

BEGIN
   FOR i IN 1..100 LOOP
	v_contador := v_contador + i;
	DBMS_OUTPUT.PUT_LINE(v_resultado || ' + ' || i || ' = ' || v_contador);
    v_resultado := v_resultado + i;
   END LOOP;
END;



5. Calcular el producto de los números del 1 al 100.

DECLARE
    v_resultado NUMBER (10) :=1;
    v_antiguo NUMBER (10) :=0;

BEGIN
   FOR i IN 1..100 LOOP
	v_antiguo := v_resultado;
	v_resultado := v_resultado * i;
	DBMS_OUTPUT.PUT_LINE(v_antiguo || ' * ' || i || ' = ' || v_resultado);
   END LOOP;
END;



6. Imprimir los múltiplos de 3 hasta N, siendo N un valor introducido por teclado.

DECLARE
    v_teclado NUMBER;
	v_numero NUMBER;

BEGIN
	v_teclado := '&Numero';
    FOR I IN 1..v_teclado LOOP
        v_numero := MOD(i, 3);
		
        IF v_numero = 0 THEN
			DBMS_OUTPUT.PUT_LINE (i);
		END IF;
    END LOOP;
END;



7. Visualizar el factorial de un número que se pide por teclado.

DECLARE
   v_resultado NUMBER :=1;
   v_num NUMBER;
   
BEGIN
   v_num := '&Numero';
   FOR i IN REVERSE 1..v_num LOOP
		v_resultado := v_resultado * i;
		  
   END LOOP;
   DBMS_OUTPUT.PUT_LINE('El factorial de '|| v_num || ' es ' || v_resultado);  
END;



8. Visualizar los factoriales de los números del 1 al 10.

DECLARE
   v_resultado NUMBER :=1;
    
BEGIN
   -- Inicio del factorial del numero j (de 1 a 100)
   FOR i IN  1..10 LOOP
      v_resultado := 1;
	  -- Factorial de lo que vale j en esta vuelta
	  FOR j IN REVERSE 1..i LOOP
	      v_resultado := v_resultado * j;
	  END LOOP;
	  
	  -- Al terminar cada vuelta muestra su resultado
	  DBMS_OUTPUT.PUT_LINE('El resultado del factorial de ' || i || ' es: ' || v_resultado); 
   END LOOP;
END;



9. Visualizar la suma de todos los números existentes entre dos introducidos por teclado.

DECLARE
v_num1 		NUMBER(3);            
v_num2 		NUMBER(3);                 
v_suma      NUMBER(5) := 0;

BEGIN 
v_num1 := '&Numero1';
v_num2 := '&Numero2';
  
    FOR i IN v_num1..v_num2 LOOP
    v_suma := v_suma +i;              
	END LOOP;
DBMS_OUTPUT.PUT_LINE(' La suma de todos los números existentes entre ' || v_num1 || ' y ' || v_num2 || ' es: ' || v_suma);
END;