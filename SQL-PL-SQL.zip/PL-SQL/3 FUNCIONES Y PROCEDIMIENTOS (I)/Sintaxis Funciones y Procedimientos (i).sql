Programación PL/SQL: Funciones Y Procedimientos (I)


[]
NOMBRE: JERÓNIMO SILVA MULERO
[]


1.Crea un procedimiento que reciba dos números y visualice su suma. Ejecuta el procedimiento usando las funcionalidades de SQL Developer.

CREATE OR REPLACE PROCEDURE SUMA1 (numero1 IN NUMBER, numero2 IN NUMBER) 
IS
BEGIN
	DBMS_OUTPUT.PUT_LINE(numero1+numero2);
END;


DECLARE 
v_n1  NUMBER;
v_n2  NUMBER;

BEGIN
v_n1 := '&Numero1';
v_n2 := '&Numero2';

SUMA1 (v_n1, v_n2);
END;




2.Crea un procedimiento que reciba dos números y devuelva su suma. Crea un bloque anónimo para probar el procedimiento.

CREATE OR REPLACE PROCEDURE SUMA2 (numero1 IN NUMBER, numero2 IN NUMBER, resultado OUT NUMBER) 
IS
BEGIN
	resultado := numero1 + numero2;
END;


DECLARE 
v_n1  NUMBER;
v_n2  NUMBER;
v_resul NUMBER;

BEGIN
v_n1 := '&Numero1';
v_n2 := '&Numero2';

SUMA2 (v_n1, v_n2, v_resul);
DBMS_OUTPUT.PUT_LINE(' El resultado de suma es ' || v_resul);
END;




3.Crea una función que reciba dos números y devuelva su suma. Crea un bloque anónimo para probar el procedimiento.

CREATE OR REPLACE FUNCTION f_suma (num1 IN NUMBER, num2 IN NUMBER) RETURN NUMBER 
IS
  --Declaramos las variables
  v_resultado NUMBER;
BEGIN
   --Ejecucion
   v_resultado := num1 + num2;
	
   RETURN v_resultado;
END;


DECLARE 
NUM1  NUMBER;
NUM2  NUMBER;
RES NUMBER;

BEGIN
NUM1 := '&Numero1';
NUM2 := '&Numero2';

RES := f_suma(NUM1, NUM2);

DBMS_OUTPUT.PUT_LINE(RES);
END;




4.Crea un procedimiento que devuelva la suma del salario de todos los mecánicos. Crea un bloque anónimo para probar el procedimiento.

--v_res es de SALIDA, OUT,  y  mecanicos.salario%type es el tipo de dato

CREATE OR REPLACE PROCEDURE P_SUSALMEC (v_res OUT mecanicos.salario%TYPE)
IS

BEGIN
  SELECT SUM (salario) INTO v_res
  FROM mecanicos;

END;


DECLARE
    v_salario mecanicos.salario%TYPE;
BEGIN

    P_SUSALMEC (v_salario);
    DBMS_OUTPUT.PUT_LINE('La suma de salarios es: ' || v_salario);

END;




5.Crea una función que devuelva la suma del salario de todos los mecánicos de un determinado puesto. Crea un bloque anónimo para probar la función.

CREATE OR REPLACE FUNCTION f_sumasalmec (v_puesto IN mecanicos.puesto%TYPE ) RETURN mecanicos.salario%TYPE
IS
   v_res mecanicos.salario%TYPE;
   
BEGIN
  SELECT SUM (salario) INTO v_res
  FROM mecanicos
  WHERE puesto = v_puesto;

  RETURN v_res;
  
END;


DECLARE
    v_puesto mecanicos.puesto%TYPE;
	v_res NUMBER;
	
BEGIN
    v_puesto := '&Puesto';
	v_res := f_sumasalmec(v_puesto);  
    DBMS_OUTPUT.PUT_LINE('La suma de salarios de todos los mecanicos de un determinado puesto es: ' || v_res);

END;




6.Crea una función que reciba el DNI de un mecánico y retorne su nombre. Prueba el procedimiento usando las funcionalidades de SQL Developer.

CREATE OR REPLACE FUNCTION f_dninombre (v_dni IN mecanicos.dni%type) RETURN mecanicos.nombre%TYPE
IS
  --Declaramos las variables
  v_res mecanicos.nombre%TYPE;
BEGIN
   --Ejecucion
   SELECT nombre INTO v_res
   FROM mecanicos
   WHERE dni = v_dni;
   
   RETURN v_res;
END;


DECLARE
    v_dni mecanicos.dni%TYPE;
    v_res mecanicos.dni%TYPE;
	
BEGIN
    v_dni := '&Dni';
    v_res := f_dninombre(v_dni);  
   DBMS_OUTPUT.PUT_LINE('El nombre del dni ' || v_dni || ' introducido por pantalla es: ' || v_res);
END;




7.Crea una función que reciba el DNI de un mecánico y retorne su salario. Prueba el procedimiento usando las funcionalidades de SQL Developer.

CREATE OR REPLACE FUNCTION f_dnisalario (v_dni IN mecanicos.dni%type) RETURN mecanicos.salario%TYPE
IS
   v_res mecanicos.salario%TYPE;
   
BEGIN
  SELECT salario INTO v_res
  FROM mecanicos
  WHERE dni = v_dni;

  RETURN v_res;
  
END;


DECLARE
    v_dni mecanicos.dni%TYPE;
    v_res NUMBER;
	
BEGIN
    v_dni := '&Dni';
    v_res := f_dnisalario(v_dni);  
    DBMS_OUTPUT.PUT_LINE('El salario del dni ' || v_dni || ' introducido por pantalla es: ' || v_res);

END;




8.Crea un procedimiento (usando las funciones creadas anteriormente) que reciba el DNI de un mecánico y retorne su nombre y su salario. 
Prueba el procedimiento usando las funcionalidades de SQL Developer

--v_res1 es de SALIDA, OUT,  y  mecanicos.dni%type es el tipo de dato de la variable v_dni, de ENTRADA, IN

CREATE OR REPLACE PROCEDURE P_NOMBREYSALARIO (v_dni IN mecanicos.dni%TYPE, v_res1 OUT mecanicos.nombre%TYPE, v_res2 OUT mecanicos.salario%TYPE)
IS

BEGIN
  SELECT nombre, salario INTO v_res1, v_res2
  FROM mecanicos
  WHERE dni = v_dni;

END;


DECLARE
    v_dni mecanicos.dni%TYPE;
    v_res1 mecanicos.nombre%TYPE;
    v_res2 mecanicos.salario%TYPE;
	
BEGIN
    v_dni := '&Dni';
    P_NOMBREYSALARIO(v_dni, v_res1, v_res2); 
	
    DBMS_OUTPUT.PUT_LINE('El dni ' || v_dni || ' corresponde al siguiente nombre: ' || v_res1 || ' y corresponde al siguiente salario: ' || v_res2);

END;




9.Crea procedimiento que modifique el puesto de un mecánico. El procedimiento recibirá como parámetros el DNI del mecánico y el nuevo puesto.

CREATE OR REPLACE PROCEDURE P_MODIFICAMECANICO (v_dni IN mecanicos.dni%TYPE, v_puesto IN mecanicos.puesto%TYPE, v_nuevopuesto IN mecanicos.puesto%TYPE)
IS

BEGIN
	UPDATE mecanicos
	SET    puesto = v_nuevopuesto
	WHERE  dni = v_dni;
END;


DECLARE
	v_dni         mecanicos.dni%TYPE;
	v_nuevopuesto mecanicos.puesto%TYPE;
	
BEGIN
	v_dni := '&Dni';
	v_nuevopuesto := '&Selecciona Un Nuevo Puesto';
	
	P_MODIFICAMECANICO (v_nuevopuesto);
    DBMS_OUTPUT.PUT_LINE('El mecanico con DNI: ' || v_dni || ' tiene un nuevo puesto, ahora es: ' || v_nuevopuesto);
END;




10.Consulta todos los procedimientos y funciones del usuario almacenados en la base de datos y su situación (valid o invalid).


SELECT OBJECT_NAME, OBJECT_TYPE, STATUS 
FROM USER_OBJECTS
WHERE OBJECT_TYPE = 'PROCEDURE' OR OBJECT_TYPE = 'FUNCTION';


----------------------------------------------------------------------------------------------------------------------------------------------------------