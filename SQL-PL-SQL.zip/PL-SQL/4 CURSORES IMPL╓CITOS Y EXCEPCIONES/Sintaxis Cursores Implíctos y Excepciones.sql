Programación PL/SQL: Cursores Implíctos Y Excepciones


[]
NOMBRE: JERÓNIMO SILVA MULERO
[]


Consideraciones previas: Únicamente se deben pedir datos por teclado o imprimir mensajes por pantalla en los bloques anónimos, 
evitando hacerlo dentro de funciones/procedimientos.


1. Crea un procedimiento que reciba el nombre de un mecánico y obtenga su DNI. Controla adecuadamente las posibles 
excepciones NO_DATA_FOUND y TOO_MANY_ROWS) (Usa las funciones SQLCODE y SQLERRM para mostrar información cuando se produzcan las excepciones).

--procedimiento P_OBTENERDNI
CREATE OR REPLACE PROCEDURE P_OBTENERDNI (v_nombre IN mecanicos.nombre%TYPE, v_dni OUT mecanicos.dni%TYPE) IS

BEGIN
   SELECT dni INTO v_dni
   FROM mecanicos
   WHERE nombre = v_nombre;
EXCEPTION 
  WHEN NO_DATA_FOUND THEN 
	  DBMS_OUTPUT.PUT_LINE (' No hay empleados con ese nombre. ');
  WHEN TOO_MANY_ROWS THEN 
	  DBMS_OUTPUT.PUT_LINE (' Hay más de un empleado con ese nombre. ');
  WHEN OTHERS THEN
	  DBMS_OUTPUT.PUT_LINE (SQLCODE || ': ' || SQLERRM);
END; 


--bloque anónimo
DECLARE
	v_midni      mecanicos.dni%TYPE;
	v_minombre  mecanicos.nombre%TYPE;
BEGIN
	v_minombre := '&Nombre';
	P_OBTENERDNI(v_minombre, v_midni);
	DBMS_OUTPUT.PUT_LINE (' El dni de '  || v_minombre || ' es ' || v_midni);
END;







2. Crea un procedimiento en el que se reciba el DNI de un mecánico y un salario y actualice a ese valor el salario de dicho mecánico. 
Si no existe el mecánico deberá mostrar un mensaje por pantalla que lo indique.

--procedimiento P_ACTUALIZASALARIO
CREATE OR REPLACE PROCEDURE P_ACTUALIZASALARIO (v_dni IN mecanicos.dni%TYPE, v_salario IN mecanicos.salario%TYPE, v_num OUT NUMBER)
IS

BEGIN
	UPDATE mecanicos
	SET salario = v_salario
	WHERE dni = v_dni;
	v_num := SQL%ROWCOUNT;
	
EXCEPTION
  WHEN NO_DATA_FOUND THEN 
	  DBMS_OUTPUT.PUT_LINE (' No existe un empleado con ese dni. ');
END;

--bloque anonimo
DECLARE
	v_dni     mecanicos.dni%TYPE;
    v_salario mecanicos.salario%TYPE;
	v_cuantos NUMBER;
BEGIN
    v_dni := '&Dni';
	v_salario := '&Salario';	
    P_ACTUALIZASALARIO (v_dni, v_salario, v_cuantos);
    DBMS_OUTPUT.PUT_LINE (' He actualizado el salario a : ' || v_cuantos || ' personas ');
END;






	
3. Actualiza el procedimiento anterior para que lance una excepción con el nombre NO_EXISTE_MECANICO (que hay que declarar previamente). 
Debes capturar la excepción.

--actualización del procedimiento P_ACTUALIZASALARIO
CREATE OR REPLACE PROCEDURE P_ACTUALIZASALARIO (v_dni IN mecanicos.dni%TYPE, v_salario IN mecanicos.salario%TYPE, v_num OUT NUMBER)
IS
	NO_EXISTE_MECANICO EXCEPTION;
	
BEGIN
	UPDATE mecanicos
	SET salario = v_salario
	WHERE dni = v_dni;
	v_num := SQL%ROWCOUNT;
	
	IF v_salario IS NULL THEN
		RAISE NO_EXISTE_MECANICO;
	END IF;
	
EXCEPTION
  WHEN NO_DATA_FOUND THEN 
	  DBMS_OUTPUT.PUT_LINE (' No existe un empleado con ese dni. ');
  WHEN NO_EXISTE_MECANICO THEN 
	  DBMS_OUTPUT.PUT_LINE (' ERROR: Salario Nulo. ');
END;


--bloque anónimo
DECLARE
	v_dni     mecanicos.dni%TYPE;
    v_salario mecanicos.salario%TYPE;
	v_cuantos NUMBER;
BEGIN
    v_dni := '&Dni';
	v_salario := '&Salario';	
    P_ACTUALIZASALARIO (v_dni, v_salario, v_cuantos);
    DBMS_OUTPUT.PUT_LINE (' He actualizado el salario a : ' || v_cuantos || ' personas ');
END;




4. Modifica el procedimiento anterior para que lance una excepción usando el procedimiento RAISE_APPLICATION_ERROR. Crea un bloque anónimo 
para probar el procedimiento (debes capturar las posibles excepciones que lance el procedimiento).

--actualización del procedimiento P_ACTUALIZASALARIO
CREATE OR REPLACE PROCEDURE P_ACTUALIZASALARIO (v_dni IN mecanicos.dni%TYPE, v_salario IN mecanicos.salario%TYPE, v_num OUT NUMBER)
IS
	
BEGIN
	UPDATE mecanicos
	SET salario = v_salario
	WHERE dni = v_dni;
	v_num := SQL%ROWCOUNT;
	
	IF v_salario IS NULL THEN
		RAISE_APPLICATION_ERROR (-20000, ' El salario actual es nulo. ');
	END IF;
	
EXCEPTION
  WHEN NO_DATA_FOUND THEN 
	    RAISE_APPLICATION_ERROR (-20001, ' No existe tal mecánico.' );
END;


--bloque anónimo
DECLARE
	v_dni     mecanicos.dni%TYPE;
    v_salario mecanicos.salario%TYPE;
	v_cuantos NUMBER;
BEGIN
    v_dni := '&Dni';
	v_salario := '&Salario';	
    P_ACTUALIZASALARIO (v_dni, v_salario, v_cuantos);
    DBMS_OUTPUT.PUT_LINE (' He actualizado el salario a : ' || v_cuantos || ' personas ');
END;
