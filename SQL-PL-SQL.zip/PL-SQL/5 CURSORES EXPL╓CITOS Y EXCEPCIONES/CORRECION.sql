Programación PL/SQL: Cursores Explícitos Y Excepciones


[]
NOMBRE: JERÓNIMO SILVA MULERO
[]


Consideraciones previas: 
Únicamente se deben pedir datos por teclado o imprimir mensajes por pantalla 
en los bloques anónimos, evitando hacerlo dentro de funciones/procedimientos.


1. Crea un procedimiento que reciba un puesto y muestre por pantalla el DNI, el nombre y el salario de todos los mecánicos de ese puesto
(utiliza un bucle while). Si no existe mecánicos del puesto indicado se debe mostrar por pantalla que no existen mecánicos de con ese puesto.


--procedimiento
CREATE OR REPLACE PROCEDURE P_DEVOLVERINFOPORPUESTO (v_puesto IN mecanicos.puesto%TYPE)
IS
	v_mecanico mecanicos%ROWTYPE;

CURSOR C_PUESTO IS
SELECT * 
FROM mecanicos 
WHERE puesto = v_puesto;

BEGIN
	IF NOT C_PUESTO%ISOPEN THEN
	OPEN C_PUESTO;
	END IF;
	
	FETCH C_PUESTO INTO v_mecanico;
	
	IF C_PUESTO%NOTFOUND THEN
	--MOSTRAR ERROR
	DBMS_OUTPUT.PUT_LINE('no hay resultados. ');
	CLOSE C_PUESTO;
	
	ELSE
	--BUCLE
	WHILE C_PUESTO%FOUND LOOP  
			DBMS_OUTPUT.PUT_LINE (' DNI: ' || v_mecanico.dni);
			DBMS_OUTPUT.PUT_LINE (' Nombre: ' || v_mecanico.nombre);
			DBMS_OUTPUT.PUT_LINE (' Salario: ' || v_mecanico.salario);
	FETCH C_PUESTO INTO v_mecanico;
	END LOOP;
	CLOSE C_PUESTO;
  END IF;
END;


--bloque anónimo
DECLARE
	mecpue mecanicos.puesto%TYPE;
	
BEGIN
	mecpue := '&Puesto'	
	P_DEVOLVERINFOPORPUESTO(mecpue);

END;



2.Realiza las acciones que se indican a continuación:

a. Actualiza el procedimiento anterior para que lance una excepción con el nombre NO_EXISTEN_MECANICOS (que hay que declarar previamente) 
cuando no existan mecánicos con ese puesto. Captura la excepción en el propio procedimiento y pruébalo.

--actualización del procedimiento P_DEVOLVERINFOPORPUESTO
CREATE OR REPLACE PROCEDURE P_DEVOLVERINFOPORPUESTO2 (v_puesto IN mecanicos.puesto%TYPE)
IS
	NO_EXISTEN_MECANICOS EXCEPTION;
	v_mecanico mecanicos%ROWTYPE;

CURSOR C_PUESTO IS
SELECT * 
FROM mecanicos 
WHERE puesto = v_puesto;

BEGIN
	IF NOT C_PUESTO%ISOPEN THEN
	OPEN C_PUESTO;
	END IF;
	
	FETCH C_PUESTO INTO v_mecanico;
	
	IF C_PUESTO%NOTFOUND THEN
	--MOSTRAR ERROR
    CLOSE C_PUESTO;
	RAISE NO_EXISTEN_MECANICOS;

	
	ELSE
	--BUCLE
	WHILE C_PUESTO%FOUND LOOP  
			DBMS_OUTPUT.PUT_LINE (' DNI: ' || v_mecanico.dni);
			DBMS_OUTPUT.PUT_LINE (' Nombre: ' || v_mecanico.nombre);
			DBMS_OUTPUT.PUT_LINE (' Salario: ' || v_mecanico.salario);
	FETCH C_PUESTO INTO v_mecanico;
	END LOOP;
	CLOSE C_PUESTO;
  END IF;
  
EXCEPTION
	WHEN NO_EXISTEN_MECANICOS THEN
		DBMS_OUTPUT.PUT_LINE('no existen mecanicos');
  
END;

--bloque anonimo
DECLARE
	mecpue mecanicos.puesto%TYPE;
	
BEGIN
	mecpue := '&Puesto'	
	P_DEVOLVERINFOPORPUESTO2(mecpue);

END;




b. Ahora captura la excepción fuera del procedimiento (en el bloque anónimo desde donde pruebas) ¿Qué ocurre? ¿Por qué?

DECLARE
	mecpue mecanicos.puesto%TYPE;
	
BEGIN
	mecpue := '&Puesto'	
	P_DEVOLVERINFOPORPUESTO2(mecpue);

EXCEPTION
	WHEN NO_EXISTEN_MECANICOS THEN 
	DBMS_OUTPUT.PUT_LINE('no existen mecanicos');
END;

---NO SE PUEDE HACER, PORQUE EN EL BLOQUE ANONIMO NO ESTA DECLARADA LA EXCEPCION NO_EXISTEN_MECANICOS, ESTÁ EN EL PROCEDIEMIENTO







c. Utiliza ahora la directiva RAISE_APPLICATION_ERROR(-20000,'No existen mecánicos con el puesto indicado') para lanzar la excepción en 
lugar de NO_EXISTEN_MECANICOS. Captura la excepción fuera del procedimiento usando PRAGMA EXCEPTION_INIT(no_existen_mecanicos,-20000);

---SE SOLUCIONARIA CREANDO UN NUEVO PROCEDIEMIENTO

CREATE OR REPLACE PROCEDURE P_DEVOLVERINFOPORPUESTO3 (v_puesto IN mecanicos.puesto%TYPE)
IS

	v_mecanico mecanicos%ROWTYPE;

CURSOR C_PUESTO IS
SELECT * 
FROM mecanicos 
WHERE puesto = v_puesto;

BEGIN
	IF NOT C_PUESTO%ISOPEN THEN
	OPEN C_PUESTO;
	END IF;
	
	FETCH C_PUESTO INTO v_mecanico;
	
	IF C_PUESTO%NOTFOUND THEN
	--MOSTRAR ERROR
    CLOSE C_PUESTO;
	RAISE_APPLICATTION_ERROR(-20000, 'No existen mecanicos con el puesto indicado');

	
	ELSE
	--BUCLE
	WHILE C_PUESTO%FOUND LOOP  
			DBMS_OUTPUT.PUT_LINE (' DNI: ' || v_mecanico.dni);
			DBMS_OUTPUT.PUT_LINE (' Nombre: ' || v_mecanico.nombre);
			DBMS_OUTPUT.PUT_LINE (' Salario: ' || v_mecanico.salario);
	FETCH C_PUESTO INTO v_mecanico;
	END LOOP;
	CLOSE C_PUESTO;
  END IF;
  
  
END;


--bloque anonimo
DECLARE
	mecpue mecanicos.puesto%TYPE;
	
	NO_EXISTEN_MECANICOS EXCEPTION;
	PRAGMA EXCEPTION_INIT(NO_EXISTEN_MECANICOS,-20000);
	
BEGIN
	mecpue := '&Puesto'	
	P_DEVOLVERINFOPORPUESTO3(mecpue);

EXCEPTION
	WHEN NO_EXISTEN_MECANICOS THEN 
	DBMS_OUTPUT.PUT_LINE('ERROR');
	
END;



3.Crea un procedimiento que reciba una marca y muestre por pantalla los datos de los coches de esa marca (utiliza un bucle for).


---procedimiento
CREATE OR REPLACE PROCEDURE P_DATOSMARCA(v_marca IN coches.marca%TYPE)
IS

v_coche cohes%ROWTYPE;

CURSOR C_MARCA IS 
SELECT * 
FROM coches
WHERE marca = v_marca;

BEGIN
	FOR v_marca IN C_MARCA LOOP
			DBMS_OUTPUT.PUT_LINE (' Matricula: ' || v_coche.matricula);
			DBMS_OUTPUT.PUT_LINE (' Modelo: ' || v_coche.modelo);
			DBMS_OUTPUT.PUT_LINE (' Año de Fabricacion: ' || v_coche.año_fabricacion);
	END LOOP
END;


--bloque anonimo
DECLARE
	v_marca cohes.marca%TYPE;
BEGIN
	v_marca := '%Marca'
	P_DATOSMARCA(v_marca);
END;



4.Crear una función denominada HorasPorCoche que reciba la matrícula de un coche y muestre el número de horas que se ha trabajado en ese coche. 
Trata las excepciones que consideres oportunas.









5.Crea un procedimiento que utilice la función anterior para mostrar por pantalla las horas trabajadas de todos los coches.


6.Crea un procedimiento que muestre los puestos de los mecánicos y el número de mecánicos de cada puesto.

