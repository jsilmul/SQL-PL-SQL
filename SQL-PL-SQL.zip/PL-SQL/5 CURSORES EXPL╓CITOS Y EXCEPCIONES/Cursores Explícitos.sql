
----cursor explícito
CREATE OR REPLACE PROCEDURE P_OBTENERDNI (v_nombre IN mecanicos.nombre%TYPE, v_dni OUT mecanicos.dni%TYPE) IS
   v_dni mecanicos.dni%TYPE;
   CURSOR CURSOR_MECANICO IS
   SELECT *
   FROM mecanicos
   WHERE nombre = v_nombre;
	
BEGIN    
	IF NOT CURSOR_MECANICO%ISOPEN THEN
	   OPEN CURSOR_MECANICO;
	END IF;
	
FETCH CURSOR_MECANICO INTO v_dni; 
WHILE CURSOR_MECANICO%FOUND
LOOP 
	  DBMS_OUTPUT.PUT_LINE (' Corresponde a el DNI: ' || v_dni);
	  FETCH CURSOR_MECANICO INTO v_dni; 
END LOOP;
CLOSE CURSOR_MECANICO;

EXCEPTION 
  WHEN NO_DATA_FOUND THEN DBMS_OUTPUT.PUT_LINE (' No hay coincidencias entre ese nombre y un DNI' );
  WHEN TOO_MANY_ROWS THEN DBMS_OUTPUT.PUT_LINE (' Hay mas de un DNI con ese nombre ');
END; 

--bloque anónimo
DECLARE
    v_nombre  mecanicos.nombre%TYPE;
	v_dni     mecanicos.dni%TYPE;
BEGIN
    v_nombre := '&Nombre';	
    P_OBTENERDNI (v_dni);
    DBMS_OUTPUT.PUT_LINE (' El mecanico con nombre: '|| v_nombre || ' corresponde a el DNI: ' || v_dni);
END;




-----------------------------------------------------------------------------------------------------------------------------------------------------




--cursor explícito
CREATE OR REPLACE PROCEDURE P_ACTUALIZASALARIO (v_dni IN mecanicos.dni%TYPE, v_salario IN mecanicos.salario%TYPE,
v_salarioactualizado OUT mecanicos.salario%TYPE)
IS

v_salarioactualizado mecanicos.salario%TYPE;
CURSOR CURSOR_ACTUALIZACION IS
UPDATE mecanicos 
SET salario = v_salarioactualizado
WHERE dni = v_dni;

BEGIN
    
	IF NOT CURSOR_ACTUALIZACION%ISOPEN THEN
	   OPEN CURSOR_ACTUALIZACION;
	END IF;
	
FETCH CURSOR_ACTUALIZACION INTO v_salarioactualizado; 
WHILE CURSOR_ACTUALIZACION%FOUND
LOOP 
DBMS_OUTPUT.PUT_LINE (' A el mecanico con DNI: '|| v_dni || ' con un salario actual  de: ' || v_salario || ' se le actualiza el salario a ' ||v_salarioactualizado);
    FETCH CURSOR_ACTUALIZACION INTO v_salarioactualizado;
END LOOP;
   
CLOSE CURSOR_ACTUALIZACION;

EXCEPTION 
  WHEN NO_DATA_FOUND THEN 
	DBMS_OUTPUT.PUT_LINE (' No existe un mecanico ese DNI' );	
END;


--bloque anónimo
DECLARE
	v_dni                mecanicos.dni%TYPE;
	v_salario            mecanicos.salario%TYPE;
	v_salarioactualizado mecanicos.salario%TYPE
	
BEGIN
    v_dni := '&Dni';
	v_salario := '&Salario';
    P_ACTUALIZASALARIO(v_salarioactualizado);
DBMS_OUTPUT.PUT_LINE (' A el mecanico con DNI: '|| v_dni || ' con un salario actual  de: ' || v_salario || ' se le actualiza el salario a ' ||v_salarioactualizado);
END;