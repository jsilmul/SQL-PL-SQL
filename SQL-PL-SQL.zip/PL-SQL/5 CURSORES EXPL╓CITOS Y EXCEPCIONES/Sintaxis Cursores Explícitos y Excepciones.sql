Programación PL/SQL: Cursores Explícitos Y Excepciones


[]
NOMBRE: JERÓNIMO SILVA MULERO
[]


Consideraciones previas: 
Únicamente se deben pedir datos por teclado o imprimir mensajes por pantalla 
en los bloques anónimos, evitando hacerlo dentro de funciones/procedimientos.


1. Crea un procedimiento que reciba un puesto y muestre por pantalla el DNI, el nombre y el salario de todos los mecánicos de ese puesto
(utiliza un bucle while). Si no existe mecánicos del puesto indicado se debe mostrar por pantalla que no existen mecánicos de con ese puesto.


CREATE OR REPLACE PROCEDURE P_MOSTRAR (v_puesto IN mecanicos.puesto%TYPE, v_dni OUT mecanicos.dni%TYPE, v_nombre OUT mecanicos.nombre%TYPE,
v_salario OUT mecanicos.salario%TYPE) IS

v_mecanico mecanicos%ROWTYPE;

CURSOR C_CURSOR1 IS
SELECT * 
FROM mecanicos
WHERE puesto = v_puesto;

BEGIN    
	IF NOT C_CURSOR1%ISOPEN THEN
	   OPEN C_CURSOR1;
	END IF;

FETCH C_CURSOR1 INTO v_mecanico;
WHILE C_CURSOR1%FOUND
LOOP
	DBMS_OUTPUT.PUT_LINE (' DNI: ' || v_mecanico.dni);
	DBMS_OUTPUT.PUT_LINE (' Nombre: ' || v_mecanico.nombre);
	DBMS_OUTPUT.PUT_LINE (' Salario: ' || v_mecanico.salario);
FETCH C_CURSOR1 INTO v_mecanico;
END LOOP;
CLOSE C_CURSOR1;

EXCEPTION 
  WHEN NO_DATA_FOUND THEN DBMS_OUTPUT.PUT_LINE (' No existen mecánicos de con ese puesto ' );
END;


--bloque anónimo
DECLARE
	v_puesto mecanicos.puesto%TYPE;
	v_dni     mecanicos.dni%TYPE;
    v_nombre  mecanicos.nombre%TYPE;
	v_salario     mecanicos.salario%TYPE;
	
BEGIN
    v_puesto := '&Puesto';	
    P_MOSTRAR (v_puesto, v_dni, v_nombre, v_salario);
DBMS_OUTPUT.PUT_LINE (' El puesto : '|| v_puesto || ' tiene estos DNIs ' || v_dni || ' ,estos nombres ' || v_nombre || ' y estos salarios ' || v_salario);
END;



2.Realiza las acciones que se indican a continuación:

a. Actualiza el procedimiento anterior para que lance una excepción con el nombre NO_EXISTEN_MECANICOS (que hay que declarar previamente) 
cuando no existan mecánicos con ese puesto. Captura la excepción en el propio procedimiento y pruébalo.

--actualización del procedimiento P_MOSTRAR
CREATE OR REPLACE PROCEDURE P_MOSTRAR (v_puesto IN mecanicos.puesto%TYPE, v_dni OUT mecanicos.dni%TYPE, v_nombre OUT mecanicos.nombre%TYPE,
v_salario OUT mecanicos.salario%TYPE) IS

v_mecanico mecanicos%ROWTYPE;
NO_EXISTEN_MECANICOS EXCEPTION;

CURSOR C_CURSOR1 IS
SELECT * 
FROM mecanicos
WHERE puesto = v_puesto;
BEGIN    
	IF NOT C_CURSOR1%ISOPEN THEN
	   OPEN C_CURSOR1;
	END IF;
        IF v_puesto IS NULL THEN
		RAISE NO_EXISTEN_MECANICOS;
	END IF;
FETCH C_CURSOR1 INTO v_mecanico;
WHILE C_CURSOR1%FOUND
LOOP
	DBMS_OUTPUT.PUT_LINE (' DNI: ' || v_mecanico.dni);
	DBMS_OUTPUT.PUT_LINE (' Nombre: ' || v_mecanico.nombre);
	DBMS_OUTPUT.PUT_LINE (' Salario: ' || v_mecanico.salario);
FETCH C_CURSOR1 INTO v_mecanico;
END LOOP;
CLOSE C_CURSOR1;

EXCEPTION 
 WHEN NO_EXISTEN_MECANICOS THEN DBMS_OUTPUT.PUT_LINE (' ERROR: No existe ese mecanico. ');
END;



b. Ahora captura la excepción fuera del procedimiento (en el bloque anónimo desde donde pruebas) ¿Qué ocurre? ¿Por qué?

DECLARE
    v_puesto mecanicos.puesto%TYPE;
    v_dni     mecanicos.dni%TYPE;
    v_nombre  mecanicos.nombre%TYPE;
    v_salario     mecanicos.salario%TYPE;
    NO_EXISTEN_MECANICOS EXCEPTION;
BEGIN
    v_puesto := '&Puesto';
    IF v_puesto IS NULL THEN
        RAISE NO_EXISTEN_MECANICOS;
    END IF;
    P_MOSTRAR (v_puesto, v_dni, v_nombre, v_salario);
DBMS_OUTPUT.PUT_LINE (' El puesto : '|| v_puesto || ' tiene estos DNIs ' || v_dni || ' ,estos nombres ' || v_nombre || ' y estos salarios ' || v_salario);
EXCEPTION 
 WHEN NO_EXISTEN_MECANICOS THEN DBMS_OUTPUT.PUT_LINE (' ERROR: No existe ese mecanico. ');
END;

Me dice que l bloque anónimo esta completado, pero en el mensaje de salida no me salen datos cuando le introduzco un puesto inexistente, en mi caso
he probado con GERENTE, que no existe en la tabla mecánicos, sólo hay MOTOR, CHAPA Y AMORTIGUACION.





c. Utiliza ahora la directiva RAISE_APPLICATION_ERROR(-20000,'No existen mecánicos con el puesto indicado') para lazar la excepción en 
lugar de NO_EXISTEN_MECANICOS. Captura la excepción fuera del procedimiento usando PRAGMA EXCEPTION_INIT(no_existen_mecanicos,-20000);

--actualización del procedimiento P_MOSTRAR 
CREATE OR REPLACE PROCEDURE P_MOSTRAR (v_puesto IN mecanicos.puesto%TYPE, v_dni OUT mecanicos.dni%TYPE, v_nombre OUT mecanicos.nombre%TYPE, 
v_salario OUT mecanicos.salario%TYPE) IS

v_mecanico mecanicos%ROWTYPE;

CURSOR C_CURSOR1 IS

SELECT * 
FROM mecanicos
WHERE puesto = v_puesto;
BEGIN    
	IF NOT C_CURSOR1%ISOPEN THEN
	   OPEN C_CURSOR1;
	END IF;
    IF v_puesto IS NULL THEN
		RAISE_APPLICATION_ERROR(-20000,'No existen mecánicos con el puesto indicado');
	END IF;

FETCH C_CURSOR1 INTO v_mecanico;
WHILE C_CURSOR1%FOUND
LOOP
	DBMS_OUTPUT.PUT_LINE (' DNI: ' || v_mecanico.dni);
	DBMS_OUTPUT.PUT_LINE (' Nombre: ' || v_mecanico.nombre);
	DBMS_OUTPUT.PUT_LINE (' Salario: ' || v_mecanico.salario);
FETCH C_CURSOR1 INTO v_mecanico;
END LOOP;
CLOSE C_CURSOR1;

EXCEPTION 
 WHEN NO_DATA_FOUND THEN RAISE_APPLICATION_ERROR(-20000,'No existen mecánicos con el puesto indicado');
END;



DECLARE
    v_puesto             mecanicos.puesto%TYPE;
    v_dni                mecanicos.dni%TYPE;
    v_nombre             mecanicos.nombre%TYPE;
    v_salario            mecanicos.salario%TYPE;
    e_no_existe_mecanico              EXCEPTION;
	PRAGMA EXCEPTION_INIT(e_no_existe_mecanico, -20001);

BEGIN
    v_puesto := '&Puesto';
    P_MOSTRAR (v_puesto, v_dni, v_nombre, v_salario);
DBMS_OUTPUT.PUT_LINE (' El puesto : '|| v_puesto || ' tiene estos DNIs ' || v_dni || ' ,estos nombres ' || v_nombre || ' y estos salarios ' || v_salario);
EXCEPTION 
 WHEN e_no_existe_mecanico THEN DBMS_OUTPUT.PUT_LINE (' ERROR: No existe ese mecanico. ');
END;



3.Crea un procedimiento que reciba una marca y muestre por pantalla los datos de los coches de esa marca (utiliza un bucle for).

CREATE OR REPLACE PROCEDURE P_DATOSPORMARCA (v_marca IN coches.marca%TYPE) IS

v_coche coches%ROWTYPE;

CURSOR C_COCHES IS

SELECT * 
FROM coches
WHERE marca = v_marca;

BEGIN
	FOR v_coches IN C_COCHES LOOP
	DBMS_OUTPUT.PUT_LINE (' Matricula: ' || v_coches.matricula);
	DBMS_OUTPUT.PUT_LINE (' Modelo: ' || v_coches.modelo);
	DBMS_OUTPUT.PUT_LINE (' Año de Fabricación: ' || v_coches.año_fabricacion);
  END LOOP;
END;



DECLARE
    v_marca           coches.marca%TYPE;
	v_matricula       coches.matricula%TYPE;
	v_modelo          coches.modelo%TYPE;
	v_año_fabricacion coches.año_fabricacion%TYPE;
	v_coches          coches%ROWTYPE;

BEGIN
    v_marca := '&Marca';
    P_DATOSPORMARCA (v_marca);

END;



4.Crear una función denominada HorasPorCoche que reciba la matrícula de un coche y muestre el número de horas que se ha trabajado en ese coche. 
Trata las excepciones que consideres oportunas.

CREATE OR REPLACE FUNCTION F_HORASPORCOCHE (v_matricula IN trabajos.matricula%TYPE) RETURN NUMBER IS

v_resultado NUMBER;
v_total NUMBER;
NO_EXISTE_MATRICULA EXCEPTION;

CURSOR C_CURSOR3 IS
SELECT horas INTO v_resultado FROM trabajos WHERE matricula = v_matricula;

BEGIN    
  IF NOT C_CURSOR3%ISOPEN THEN
     OPEN C_CURSOR3;
  END IF;	
  FETCH C_CURSOR3 INTO v_resultado;
IF C_CURSOR3%FOUND THEN 
  WHILE C_CURSOR3%FOUND  
  LOOP
  DBMS_OUTPUT.PUT_LINE (' Horas trabajadas: ' || v_resultado);
  DBMS_OUTPUT.PUT_LINE (' Total: ' || v_total);
  v_total := (v_total + v_resultado);
  FETCH C_CURSOR3 INTO v_resultado;
  END LOOP;
  CLOSE C_CURSOR3;
  RETURN v_total;
ELSE
  CLOSE C_CURSOR3;
  RAISE NO_EXISTE_MATRICULA;
END IF;
EXCEPTION 
 WHEN NO_EXISTE_MATRICULA THEN DBMS_OUTPUT.PUT_LINE (' ERROR: No existe esa matricula. ');
END;



DECLARE
    v_matricula	trabajos.matricula%TYPE;
    v_resultado trabajos.horas%TYPE;
	
BEGIN
	v_matricula := '&Matricula';
	v_resultado := F_HORASPORCOCHE(v_matricula);
	DBMS_OUTPUT.PUT_LINE (' La matricula: ' || v_matricula || ' ha pasado ' || v_resultado || ' horas en el taller ');

END;





5.Crea un procedimiento que utilice la función anterior para mostrar por pantalla las horas trabajadas de todos los coches.


6.Crea un procedimiento que muestre los puestos de los mecánicos y el número de mecánicos de cada puesto.

CREATE OR REPLACE PROCEDURE P_MOSTRARPUESTOS (v_puesto IN mecanicos.puesto%TYPE)
IS
v_puesto    mecanicos.puesto%TYPE;
v_dni       mecanicos.dni%TYPE;
v_num_mecan NUMBER;

CURSOR C_PUESTO IS
SELECT puesto, COUNT(dni)
FROM mecanicos
WHERE dni = v_dni
GROUP BY puesto;

BEGIN
OPEN C_PUESTO;
FETCH C_PUESTO INTO v_puesto, v_num_mecan;
WHILE C_PUESTO%FOUND LOOP
DBMS_OUTPUT.PUT_LINE( ' El puesto: ' || v_puesto || ' tiene ' ||v_num_mecan || ' mecanicos' );
FETCH C_PUESTO into v_puesto,v_num_mecan;
END LOOP;
CLOSE C_PUESTO;
END P_MOSTRARPUESTOS;

DECLARE
    v_puesto    mecanicos.puesto%TYPE;
    v_dni       mecanicos.dni%TYPE;
	v_num_mecan NUMBER;
	
BEGIN
	v_puesto := '&Puesto';
    P_MOSTRARPUESTOS (v_puesto, v_dni, v_num_mecan);
	DBMS_OUTPUT.PUT_LINE (' El puesto: ' || v_puesto || ' tiene ' || v_num_mecan || ' mecanicos ');

END;