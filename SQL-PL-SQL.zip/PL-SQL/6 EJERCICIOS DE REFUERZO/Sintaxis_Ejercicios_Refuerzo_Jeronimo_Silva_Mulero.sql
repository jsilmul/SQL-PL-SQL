Programación PL/SQL: Ejercicios de Refuerzo


NOMBRE: JERÓNIMO SILVA MULERO........................................................

Nota previa: Todos los scripts deben ir acompañados de un bloque anónimo y del correspondiente  tratamiento de excepciones


1. Crea un procedimiento que actualice el ganador del premio de un puerto. 

--procedimiento
CREATE OR REPLACE PROCEDURE P_GANADOR (v_nombre IN puerto.nompuerto%TYPE, v_dorsal IN puerto.dorsal%TYPE)IS
NO_EXISTE_PUERTO EXCEPTION;
BEGIN
UPDATE puerto
SET dorsal = v_dorsal
WHERE nompuerto= v_nombre;
IF SQL%ROWCOUNT = 0 THEN
	RAISE NO_EXISTE_PUERTO;
END IF;

EXCEPTION
	WHEN NO_EXISTE_PUERTO THEN
	DBMS_OUTPUT.PUT_LINE(' No existe ese puerto');
END;

--bloque anonimo
DECLARE
	v_puerto puerto.nompuerto%TYPE; 
	v_dorsal puerto.dorsal%TYPE;
BEGIN
	v_puerto := '&Puerto';
	v_dorsal := '&Dorsal';
	P_GANADOR(v_nombre, v_dorsal);
END;

2. Crea un procedimiento que enumere los puertos con una pendiente mayor que 6. Utiliza 
ambos tipos de cursor explícito.
CREATE OR REPLACE PROCEDURE P_ENUMERAR (v_enumeracion OUT NUMBER) IS

CURSOR C_CURSORPENDIENTE IS
SELECT * FROM puerto;
v_puerto puerto%ROWTYPE;

BEGIN 
v_enumeracion := 0;
OPEN C_CURSORPENDIENTE;
FETCH C_CURSORPENDIENTE INTO v_puerto;
WHILE C_CURSORPENDIENTE%FOUND LOOP
	IF v_puerto.pendiente >= 6 THEN
    v_enumeracion := v_enumeracion + 1;
    END IF;
	FETCH C_CURSORPENDIENTE INTO v_puerto;
  END LOOP;
 CLOSE C_CURSORPENDIENTE;
END;

--bloque anonimo
DECLARE
v_contador NUMBER;
BEGIN
P_ENUMERAR(v_contador);
DBMS_OUTPUT.PUT_LINE('Hay ' || v_contador || ' puertos con seis o más de pendiente');
END;


3. Crea una función que acepte el nombre del puerto y devuelva la pendiente del mismo. Si la 
pendiente es superior a 7, debe lanzarse una excepción de usuario.

CREATE OR REPLACE PROCEDURE F_DEVOLVERPENDIENTE (v_nompuerto IN puerto.nompuerto%TYPE) RETURN puerto.pendiente%TYPE IS
PENDIENTE_MUY_GRANDE EXCEPTION;
NO_EXISTE_PUERTO EXCEPTION;
v_pendiente puerto.pendiente%TYPE;

BEGIN
SELECT pendiente INTO v_pendiente FROM puerto WHERE nompuerto = v_nompuerto;
	IF SQL%ROWCOUNT = 0 THEN
	  RAISE NO_EXISTE_PUERTO;
	END IF;
	IF v_pendiente >= 7 THEN
	  RAISE PENDIENTE_MUY_GRANDE;
	END IF;
  RETURN v_pendiente;
WHEN PPENDIENTE_MUY_GRANDE THEN
    DBMS_OUTPUT.PUT_LINE('La pendiente es mayor que 7');
WHEN NO_EXISTE_PUERTO THEN
    DBMS_OUTPUT.PUT_LINE('No existe tal puerto');
END;

--bloque anonimo 
DECLARE
	v_pendiente puerto.pendiente%TYPE;
	v_nompuerto puerto.nompuerto%TYPE;
	
BEGIN
	v_nompuerto := '&NombredelPuerto';
	F_DEVOLVERPENDIENTE(v_nompuerto);
	DBMS_OUTPUT.PUT_LINE(' El puerto ' || v_nompuerto || ' tiene una pendiente de ' || v_pendiente || ' kms');
END;

4. Crea un procedimiento que acepte una categoría de puerto y liste todos los puertos de esa 
categoría. Utiliza ambos tipos de cursor explícito.

CREATE OR REPLACE PROCEDURE P_LISTARPUERTOS (v_categoria IN puerto.categoria%TYPE, v_contador OUT NUMBER) IS

CURSOR C_CURSOREJERCICIO4 IS
SELECT FROM puerto;
v_puerto puerto%ROWTYPE;
BEGIN
v_contador := 0;
OPEN C_CURSOREJERCICIO4;
FETCH C_CURSOREJERCICIO4 INTO v_puerto;
WHILE C_CURSOREJERCICIO4%FOUND LOOP
IF v_puerto.categoria = v_categoria THEN
v_contador := v_contador + 1;
END IF;
FETCH C_CURSOREJERCICIO4 INTO v_puerto;
END LOOP;
CLOSE C_CURSOREJERCICIO4;
END;

--bloque anonimo
DECLARE
v_cont NUMBER;
v_categoria puerto.categoria%TYPE;
BEGIN
v_categoria := '&Categoria';
ContarCategoria(v_categoria, v_cont);
IF v_cont = 0 THEN 
DBMS_OUTPUT.PUT_LINE('No existe la categoria');
ELSE
DBMS_OUTPUT.PUT_LINE('Hay ' || v_cont || ' puertos con la categoría ' || v_categoria);
END IF;
END;

5. Crea una función que acepte un número de dorsal y retorne la cantidad de puertos que ha 
ganado. Si ha ganado más de 1 puerto, lanzar la excepción “experto”.

6. Crea un procedimiento que acepte un número de etapa y una cantidad de kilómetros y 
actualice los datos de la etapa. Además debe devolver (dato de salida) el dorsal del ciclista 
que la ganó.

7. Crea un procedimiento que acepte un nombre de equipo y un nombre de director y añada 
éste a la tabla de equipos.

8. Crea una función que acepte un nombre de equipo y devuelva la cantidad de integrantes del 
equipo. En el caso de haber menos de 5 ciclistas, lanzar una excepción de usuario sin 
nombre que será recogida en el bloque anónimo